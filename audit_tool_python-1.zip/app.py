#!/usr/bin/env python3
"""
Review dashboard for the audit tool. Run with:

    streamlit run app.py

Gives reviewers a single screen to: kick off a run for any number of
notification numbers (pasted, or uploaded from a file), watch live progress
against both SAP systems, browse/filter the flagged rows, work through the
error list with a persistent approve/reject/comment workflow, and look up
what each rule means -- all without opening Excel.
"""
from __future__ import annotations
import io
import math
import re
from datetime import datetime

import pandas as pd
import streamlit as st

from audit_tool import config as c
from audit_tool import lookups, review_store, fiscaliz_store, excel_export, run_state
from audit_tool.pipeline import run as run_pipeline, recompute as recompute_pipeline

# Drop a logo.png here to brand the app -- picked up automatically, no code
# changes needed. Falls back to a plain icon/title if there isn't one.
LOGO_PATH = c.DATA_DIR.parent / "assets" / "logo.png"
_HAS_LOGO = LOGO_PATH.exists()

st.set_page_config(
    page_title="Auditoria de Relatório Resumido",
    page_icon=str(LOGO_PATH) if _HAS_LOGO else "🔎",
    layout="wide",
)


def render_header(subtitle: str | None = None) -> None:
    if _HAS_LOGO:
        col_logo, col_title = st.columns([1, 9])
        with col_logo:
            st.image(str(LOGO_PATH), width=72)
        with col_title:
            st.title("Auditoria de Relatório Resumido")
            if subtitle:
                st.caption(subtitle)
    else:
        st.title("🔎 Auditoria de Relatório Resumido")
        if subtitle:
            st.caption(subtitle)


# Sidebar branding too, if a logo is available.
if _HAS_LOGO:
    st.sidebar.image(str(LOGO_PATH), width="stretch")



# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------

@st.cache_data
def _load_rule_explanations() -> pd.DataFrame:
    return pd.read_csv(c.DATA_DIR / "explicacao_regras.csv")


def _parse_notas(pasted_text: str, uploaded_file) -> list[str]:
    notas: list[str] = []
    if uploaded_file is not None:
        name = uploaded_file.name.lower()
        if name.endswith((".xlsx", ".xls")):
            df = pd.read_excel(uploaded_file, header=None)
        else:
            df = pd.read_csv(uploaded_file, header=None, dtype=str)
        notas += (
            df.iloc[:, 0].dropna().astype(str).str.strip().tolist()
        )
    if pasted_text.strip():
        notas += [n.strip() for n in re.split(r"[,\s;]+", pasted_text.strip()) if n.strip()]
    # de-dup, keep order, strip trailing ".0" from Excel-y floats
    seen, cleaned = set(), []
    for n in notas:
        n = re.sub(r"\.0$", "", n)
        if n and n not in seen:
            seen.add(n)
            cleaned.append(n)
    return cleaned


def _to_excel_bytes(df: pd.DataFrame) -> bytes:
    return excel_export.styled_excel_bytes(df)


def _paginate(df: pd.DataFrame, key: str, default_size: int = 50) -> pd.DataFrame:
    n = len(df)
    if n == 0:
        return df
    c1, c2, c3 = st.columns([1, 1, 3])
    with c1:
        page_size = st.selectbox(
            "Linhas por página", [25, 50, 100, 250, 500], index=1, key=f"{key}_size"
        )
    total_pages = max(1, math.ceil(n / page_size))
    with c2:
        page = st.number_input(
            "Página", min_value=1, max_value=total_pages, value=1, step=1, key=f"{key}_page"
        )
    start = (page - 1) * page_size
    end = min(start + page_size, n)
    with c3:
        st.caption(f"Mostrando linhas **{start + 1}-{end}** de **{n}**  ·  {total_pages} página(s)")
    return df.iloc[start:end]


def _status_badge(alerta: str) -> str:
    return "🔴 Sim" if alerta == "Sim" else "🟢 Não"


# ----------------------------------------------------------------------------
# Sidebar: run controls
# ----------------------------------------------------------------------------

st.sidebar.title("🔎 Auditoria Rel. Resumido")
st.sidebar.caption("Substituto em Python da planilha VBA original")

# --- Restore the last saved run, once per session, before any widgets are
# built -- so the notas textarea can be pre-filled with what was running.
if "results" not in st.session_state:
    st.session_state.results = None
    st.session_state.run_at = None
    st.session_state.restored_at = None
    saved = run_state.load()
    if saved is not None:
        try:
            restored = recompute_pipeline(
                saved["consolidated"],
                reviewer=saved.get("reviewer"),
                notas=saved.get("notas"),
                export_results=saved.get("export_results"),
            )
            restored["export_results"] = saved.get("export_results")
            st.session_state.results = restored
            st.session_state.run_at = datetime.fromisoformat(saved["saved_at"])
            st.session_state.restored_at = saved["saved_at"]
            st.session_state.setdefault("notas_pasted", "\n".join(saved.get("notas", [])))
        except Exception:
            pass  # corrupted/incompatible saved state -- just start fresh

if st.session_state.restored_at:
    st.sidebar.info(
        f"🔄 Última execução restaurada (salva em {st.session_state.restored_at}). "
        "Nenhum dado novo foi buscado no SAP."
    )

with st.sidebar.expander("① Notas para processar", expanded=True):
    pasted = st.text_area(
        "Cole os números das notas (uma por linha, ou separadas por vírgula/espaço)",
        height=100,
        placeholder="6793267\n6793268\n300001031925",
        key="notas_pasted",
    )
    uploaded = st.file_uploader("...ou envie um arquivo (.txt, .csv, .xlsx)", type=["txt", "csv", "xlsx", "xls"])
    notas = _parse_notas(pasted, uploaded)
    if notas:
        st.success(f"{len(notas)} nota(s) reconhecida(s).")

with st.sidebar.expander("② Opções", expanded=True):
    skip_sap = st.checkbox(
        "Pular extração do SAP",
        value=False,
        help=f"Use se os arquivos '<Nota> - Relatório Resumido.xls' já estiverem em {c.DADOS_DIR}",
    )
    resume_run = st.checkbox(
        "Retomar execução anterior (não baixar de novo o que já foi baixado)",
        value=True,
        help="Se uma execução anterior parou no meio (queda do SAP, etc.), "
             "notas cujo arquivo já existe são reaproveitadas em vez de buscadas de novo.",
    )
    reviewer = st.text_input("Seu nome (para a lista de erros e revisões)", value="")

run_clicked = st.sidebar.button(
    "▶ Executar Análise", type="primary", width="stretch", disabled=not notas
)

if st.session_state.results is not None:
    if st.sidebar.button("🗑️ Descartar execução salva", width="stretch"):
        run_state.clear()
        st.session_state.results = None
        st.session_state.run_at = None
        st.session_state.restored_at = None
        st.rerun()

if run_clicked:
    progress_bar = st.sidebar.progress(0.0)
    status_line = st.sidebar.empty()

    def _on_progress(stage, current, total, message):
        pct = (current / total) if total else 0.0
        progress_bar.progress(min(max(pct, 0.0), 1.0))
        status_line.caption(message)

    with st.spinner("Processando..."):
        try:
            results = run_pipeline(
                notas,
                skip_sap=skip_sap,
                reviewer=reviewer or None,
                progress_callback=_on_progress,
                resume=resume_run,
            )
            st.session_state.results = results
            st.session_state.run_at = datetime.now()
            st.session_state.restored_at = None
            progress_bar.progress(1.0)
            status_line.caption("Concluído.")
        except Exception as exc:
            st.sidebar.error(f"Falha na execução: {exc}")
            raise

results = st.session_state.results

if results is None:
    render_header()
    st.info(
        "Cole ou envie as notas na barra lateral e clique em **Executar Análise** "
        "para começar. Nesta tela você poderá filtrar todas as linhas, revisar "
        "cada problema encontrado e consultar o que cada regra significa."
    )
    with st.expander("📖 Ver todas as regras de auditoria (sem executar nada)"):
        st.dataframe(_load_rule_explanations(), width="stretch", hide_index=True)
    st.stop()

flagged = results["flagged"]
errors_raw = results["errors"]
export_results = results.get("export_results")
run_at = st.session_state.run_at

render_header(f"Última execução: {run_at:%d/%m/%Y %H:%M:%S} · {len(notas)} nota(s) solicitada(s)")

tab_overview, tab_notas, tab_errors, tab_rules, tab_missing = st.tabs(
    ["📊 Visão Geral", "📋 Linhas Analisadas", "⚠️ Erros / Revisão", "📖 Regras", "🔍 Notas Não Encontradas"]
)

# ----------------------------------------------------------------------------
# Overview
# ----------------------------------------------------------------------------
with tab_overview:
    if flagged.empty:
        st.warning("Nenhuma linha foi consolidada -- verifique se os arquivos de exportação existem.")
    else:
        n_rows = len(flagged)
        n_alert = int((flagged["Alerta"] == "Sim").sum())
        n_notas_ok = flagged[c.COL_NOTA].nunique()
        n_issues = len(errors_raw)
        n_missing = (
            sum(1 for r in export_results.values() if r["path"] is None) if export_results else 0
        )

        m1, m2, m3, m4, m5 = st.columns(5)
        m1.metric("Notas com dados", n_notas_ok)
        m2.metric("Linhas analisadas", f"{n_rows:,}".replace(",", "."))
        m3.metric("Linhas com alerta", f"{n_alert:,}".replace(",", "."), f"{100*n_alert/n_rows:.1f}%")
        m4.metric("Problemas individuais", n_issues)
        if export_results:
            m5.metric("Notas não encontradas", n_missing)

        n_pending_fiscaliz = int(
            (flagged[c.COL_FISCALIZ].isna() | (flagged[c.COL_FISCALIZ].astype(str).str.strip() == "")).sum()
        )
        if n_pending_fiscaliz:
            st.warning(
                f"⏳ **{n_pending_fiscaliz} linha(s)** ainda sem valor de **Fiscalização** "
                "preenchido -- regras que dependem dele (Divergência Fisc. x Executado, "
                "limites de horas, etc.) não vão disparar até serem preenchidas. "
                "Preencha na aba **📋 Linhas Analisadas**."
            )

        st.subheader("Ocorrências por regra")
        if not errors_raw.empty:
            counts = (
                errors_raw["Nome Verificação"].value_counts().sort_values(ascending=True)
            )
            st.bar_chart(counts, horizontal=True, height=max(300, 22 * len(counts)))
        else:
            st.success("Nenhum problema encontrado. 🎉")

        st.subheader("Notas com mais problemas")
        if not errors_raw.empty:
            top_notas = (
                errors_raw.groupby("Nota").size().sort_values(ascending=False).head(15)
            )
            st.bar_chart(top_notas)

# ----------------------------------------------------------------------------
# Linhas Analisadas (wide table, every rule column)
# ----------------------------------------------------------------------------
with tab_notas:
    if flagged.empty:
        st.info("Sem dados.")
    else:
        f1, f2, f3, f4 = st.columns([2, 2, 1, 2])
        with f1:
            nota_filter = st.multiselect(
                "Nota", sorted(flagged[c.COL_NOTA].dropna().unique().tolist())
            )
        with f2:
            search = st.text_input("Buscar (Ponto, UnC ou Descrição)", "")
        with f3:
            alerta_filter = st.selectbox("Alerta", ["Todos", "Sim", "Não"])
        with f4:
            rule_filter = st.selectbox("Apenas linhas com esta regra ativa", ["Qualquer"] + c.RULE_COLUMNS)

        only_pending_fiscaliz = st.checkbox(
            "Mostrar apenas linhas sem valor de Fiscalização preenchido", value=False
        )

        view = flagged
        if nota_filter:
            view = view[view[c.COL_NOTA].isin(nota_filter)]
        if search:
            mask = (
                view[c.COL_PV].astype(str).str.contains(search, case=False, na=False)
                | view[c.COL_UNC].astype(str).str.contains(search, case=False, na=False)
                | view[c.COL_DESCRICAO].astype(str).str.contains(search, case=False, na=False)
            )
            view = view[mask]
        if alerta_filter != "Todos":
            view = view[view["Alerta"] == alerta_filter]
        if rule_filter != "Qualquer":
            view = view[view[rule_filter] != ""]
        if only_pending_fiscaliz:
            view = view[view[c.COL_FISCALIZ].isna()]

        display = view.copy()
        display["Alerta"] = display["Alerta"].map(_status_badge)

        st.download_button(
            "⬇️ Baixar linhas filtradas (Excel)",
            data=_to_excel_bytes(view),
            file_name="linhas_filtradas.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

        page = _paginate(display, key="notas")

        editable_cols = [c.COL_NOTA, c.COL_PV, c.COL_UNC, c.COL_DESCRICAO, c.COL_OPERATION,
                          c.COL_TP_EXEC, c.COL_PLANEJ, c.COL_EXEC, c.COL_FISCALIZ, "Alerta"]
        disabled_cols = [col for col in editable_cols if col != c.COL_FISCALIZ]
        st.caption(
            "✏️ **Fiscalização** é preenchida manualmente (não vem do SAP). Edite os "
            "valores abaixo e clique em **Salvar** para recalcular as regras na hora."
        )
        edited_notas = st.data_editor(
            page[editable_cols + [c.COL_LINHA_ID]],
            width="stretch",
            hide_index=True,
            height=560,
            disabled=disabled_cols + [c.COL_LINHA_ID],
            column_config={c.COL_LINHA_ID: None},  # hide the id column, keep it in the data
            key="notas_editor",
        )

        if st.button("💾 Salvar Fiscalização e recalcular regras", type="primary"):
            changed = edited_notas[[c.COL_LINHA_ID, c.COL_FISCALIZ]].copy()
            fiscaliz_store.upsert_bulk([
                {"linha_id": r[c.COL_LINHA_ID], "valor": str(r[c.COL_FISCALIZ]),
                 "reviewer": reviewer or "desconhecido"}
                for _, r in changed.iterrows()
            ])
            full_consolidated = results["consolidated"].copy()
            valor_map = changed.set_index(c.COL_LINHA_ID)[c.COL_FISCALIZ]
            has_edit = full_consolidated[c.COL_LINHA_ID].isin(valor_map.index)
            full_consolidated.loc[has_edit, c.COL_FISCALIZ] = (
                full_consolidated.loc[has_edit, c.COL_LINHA_ID].map(valor_map)
            )
            new_results = recompute_pipeline(
                full_consolidated,
                reviewer=reviewer or None,
                notas=None,  # derive from full_consolidated itself, not the sidebar textarea
                export_results=results.get("export_results"),
            )
            new_results["export_results"] = results.get("export_results")
            st.session_state.results = new_results
            st.session_state.run_at = datetime.now()
            st.session_state.restored_at = None
            st.success(f"{len(changed)} valor(es) de Fiscalização salvo(s) e regras recalculadas.")
            st.rerun()


# ----------------------------------------------------------------------------
# Erros / Revisão (review workflow)
# ----------------------------------------------------------------------------
with tab_errors:
    if errors_raw.empty:
        st.success("Nenhum problema encontrado. 🎉")
    else:
        merged = review_store.merge_into_errors(errors_raw)

        f1, f2, f3 = st.columns([2, 2, 2])
        with f1:
            rule_sel = st.multiselect("Regra", sorted(merged["Nome Verificação"].unique().tolist()))
        with f2:
            status_sel = st.multiselect("Status", review_store.STATUSES)
        with f3:
            nota_sel = st.text_input("Buscar por Nota ou Ponto", "")

        view = merged
        if rule_sel:
            view = view[view["Nome Verificação"].isin(rule_sel)]
        if status_sel:
            view = view[view["Status"].isin(status_sel)]
        if nota_sel:
            m = (
                view["Nota"].astype(str).str.contains(nota_sel, case=False, na=False)
                | view["Ponto"].astype(str).str.contains(nota_sel, case=False, na=False)
            )
            view = view[m]

        n_pending = int((view["Status"] == "Pendente").sum())
        st.progress(
            0 if len(view) == 0 else 1 - n_pending / len(view),
            text=f"{len(view) - n_pending}/{len(view)} revisado(s) neste filtro",
        )

        st.download_button(
            "⬇️ Baixar lista de erros (Excel)",
            data=_to_excel_bytes(view),
            file_name="lista_de_erros.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

        page = _paginate(view, key="errors")

        st.caption("Edite **Status** e **Comentário** diretamente na tabela e clique em Salvar.")
        edited = st.data_editor(
            page,
            width="stretch",
            hide_index=True,
            height=560,
            disabled=["Nota", "Ponto", "UnC", "Descrição", "Nome Verificação", "Resultado Alerta",
                      "Revisado Por", "Atualizado Em"],
            column_config={
                "Status": st.column_config.SelectboxColumn(options=review_store.STATUSES, required=True),
                "Comentário": st.column_config.TextColumn(width="large"),
            },
            key="errors_editor",
        )

        if st.button("💾 Salvar alterações desta página", type="primary"):
            changed_rows = []
            for _, row in edited.iterrows():
                changed_rows.append({
                    "nota": row["Nota"], "ponto": row["Ponto"], "unc": row["UnC"],
                    "rule": row["Nome Verificação"], "status": row["Status"],
                    "comment": row["Comentário"], "reviewer": reviewer or "desconhecido",
                })
            review_store.upsert_bulk(changed_rows)
            st.success(f"{len(changed_rows)} registro(s) salvo(s).")
            st.rerun()

# ----------------------------------------------------------------------------
# Regras (reference + hit counts)
# ----------------------------------------------------------------------------
with tab_rules:
    rules_df = _load_rule_explanations()
    search_rule = st.text_input("Buscar regra", "")
    view = rules_df
    if search_rule:
        mask = (
            view["Regra"].str.contains(search_rule, case=False, na=False)
            | view["Explicação"].str.contains(search_rule, case=False, na=False)
        )
        view = view[mask]

    if not errors_raw.empty:
        hit_counts = errors_raw["Nome Verificação"].value_counts()
        view = view.copy()
        view["Ocorrências nesta execução"] = view["Regra"].map(hit_counts).fillna(0).astype(int)

    st.dataframe(view, width="stretch", hide_index=True, height=600)

# ----------------------------------------------------------------------------
# Notas Não Encontradas
# ----------------------------------------------------------------------------
with tab_missing:
    if export_results is None:
        st.info(
            "Esta execução pulou a extração do SAP ('Pular extração do SAP' marcado), "
            "então não há informação de busca por sistema."
        )
    else:
        rows = []
        for nota, r in export_results.items():
            rows.append({
                "Nota": nota,
                "Encontrada em": r["system"] or "Nenhum sistema",
                "Caminho do arquivo": str(r["path"]) if r["path"] else "",
                "Último erro": r["error"] or "",
            })
        missing_df = pd.DataFrame(rows)
        only_missing = st.checkbox("Mostrar apenas as não encontradas", value=True)
        if only_missing:
            missing_df = missing_df[missing_df["Encontrada em"] == "Nenhum sistema"]
        st.dataframe(missing_df, width="stretch", hide_index=True, height=500)
        if len(missing_df):
            st.download_button(
                "⬇️ Baixar lista (Excel)",
                data=_to_excel_bytes(missing_df),
                file_name="notas_nao_encontradas.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
