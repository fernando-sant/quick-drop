"""
Replaces X_Logar_ERP.bas + B_Salvar_Resumido.bas + Z_Encerrar_SAP.bas.

Requires, on the machine that runs this:
  - Windows
  - SAP GUI for Windows installed, with scripting enabled
    (SAP Logon -> Options -> Accessibility & Scripting -> Scripting: "Enable
    scripting" checked, and the same setting enabled server-side by your
    Basis team)
  - pywin32   (pip install pywin32)

This is a 1:1 behavioral port of the VBA: same transaction (IQS2), same tab
navigation, same DMS attachment export. It is NOT testable outside a real
SAP GUI session, so treat it as a starting point to re-verify against your
SAP screens (element IDs shift between SAP versions/variants) rather than a
drop-in guarantee.
"""
from __future__ import annotations
import logging
import time
from pathlib import Path

from . import config as c

log = logging.getLogger(__name__)


def _get_sap_scripting_engine():
    import win32com.client

    sap_gui_auto = win32com.client.GetObject("SAPGUI")
    application = sap_gui_auto.GetScriptingEngine
    return application


class DocumentNotFoundError(Exception):
    """Raised when the DMS search for a Nota's 'RelResumido' attachment
    comes back empty in the currently-connected SAP system -- the signal to
    try the next system in config.SAP_CONNECTIONS."""


def _find_existing_connection(application, connection_name: str):
    """Reuse an already-open SAP GUI connection whose description matches
    connection_name, instead of always trusting Children(0) like the
    original macro did -- that broke once more than one system could be
    open at a time."""
    for i in range(application.Children.Count):
        conn = application.Children(i)
        try:
            if connection_name.lower() in conn.Description.lower():
                return conn
        except Exception:
            continue
    return None


def connect_or_open_sap(connection: dict | None = None, timeout_s: int = 20):
    """Equivalent of Logar_ERP, but targets a *specific* SAP system
    (connection['name'] as it appears in SAP Logon) instead of whichever
    connection happens to be open. Reuses it if already connected.

    `connection` defaults to the first entry in config.SAP_CONNECTIONS
    (the current production system).
    """
    connection = connection or c.SAP_CONNECTIONS[0]
    connection_name = connection["name"]

    try:
        application = _get_sap_scripting_engine()
    except Exception:
        application = None

    if application is None:
        import subprocess
        subprocess.Popen([str(c.SAP_LOGON_PATH)])
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            time.sleep(2)
            try:
                application = _get_sap_scripting_engine()
                if application is not None:
                    break
            except Exception:
                continue
        if application is None:
            raise RuntimeError("Could not start/attach to SAP GUI scripting engine.")

    existing = _find_existing_connection(application, connection_name)
    if existing is not None and existing.Children.Count > 0:
        log.info("Reusing open SAP session for '%s'.", connection_name)
        return existing.Children(0)

    log.info("Opening SAP connection '%s'...", connection_name)
    sap_connection = application.OpenConnection(connection_name, True)
    if sap_connection is None:
        raise RuntimeError(f"Could not open SAP connection '{connection_name}'.")
    session = sap_connection.Children(0)
    session.findById("wnd[0]").maximize()
    return session


def export_relatorio_resumido(session, nota: str, dest_dir: Path = c.DADOS_DIR) -> Path:
    """Equivalent of BUSCAR_REL_RESUMIDO for a single Nota: navigate to
    IQS2, open the DMS/Documents tab, find the '<nota>-RelResumido*' file,
    and export it to dest_dir. Returns the expected output path.

    NOTE: the SAP element IDs below (tabsTAB_GROUP_10, ctxtSTDKTXT-LOW, ...)
    are copied verbatim from the working VBA macro. If your SAP GUI layout
    or transaction variant differs, re-record with SAP's own script recorder
    and diff against this function.
    """
    filename = f"{nota} - Relatório Resumido.xls"
    dest_dir.mkdir(parents=True, exist_ok=True)

    session.findById("wnd[0]/tbar[0]/okcd").text = "/NIQS2"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[0]/usr/ctxtRIWO00-QMNUM").text = nota
    session.findById("wnd[0]").sendVKey(0)

    tab_path = "wnd[0]/usr/tabsTAB_GROUP_10/tabp10\\TAB19"
    session.findById(tab_path).select()
    session.findById(
        "wnd[0]/usr/tabsTAB_GROUP_10/tabp10\\TAB19/ssubSUB_GROUP_10:SAPLIQS0:7235/"
        "subCUSTOM_SCREEN:SAPLIQS0:7212/subSUBSCREEN_1:SAPLIQS0:7801/"
        "subDVS:SAPLCV140:0204/btnX5"
    ).press()

    search_field = (
        "wnd[0]/usr/tabsMAINSTRIP/tabpTAB1/ssubSUBSCRN:SAPLCV100:0401/"
        "ssubSCR_MAIN:SAPLCV100:0402/txtSTDKTXT-LOW"
    )
    session.findById(search_field).text = f"{nota}-RelResumido*.xls*"
    session.findById(search_field).setFocus()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    session.findById("wnd[0]/tbar[1]/btn[33]").press()

    grid = "wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell"
    try:
        row_count = session.findById(grid).RowCount
    except Exception as exc:
        raise DocumentNotFoundError(
            f"Nota {nota}: search results grid not available (window may not "
            f"have opened) -- {exc}"
        ) from exc
    if row_count == 0:
        session.findById("wnd[1]").close()
        raise DocumentNotFoundError(f"Nota {nota}: no 'RelResumido' attachment found.")

    session.findById(grid).currentCellRow = 3
    session.findById(grid).selectedRows = "3"
    session.findById(grid).clickCurrentCell()

    session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell").currentCellColumn = ""
    session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell").selectedRows = "0"
    session.findById("wnd[0]/tbar[1]/btn[45]").press()

    files_tree = (
        "wnd[0]/usr/tabsTAB_MAIN/tabpTSMAIN/ssubSCR_MAIN:SAPLCV110:0102/"
        "cntlCTL_FILES1/shellcont/shell/shellcont[1]/shell"
    )
    session.findById(files_tree).selectNode("          1")
    session.findById(files_tree).nodeContextMenu("          1")
    session.findById(files_tree).selectContextMenuItem("CF_EXP_COPY")

    session.findById("wnd[1]/usr/ctxtDRAW-DTTRG").text = ""
    session.findById("wnd[1]/usr/ctxtDRAW-FILEP").setFocus()
    session.findById("wnd[1]").sendVKey(4)
    session.findById("wnd[2]/usr/ctxtDY_PATH").setFocus()
    session.findById("wnd[2]").sendVKey(4)
    session.findById("wnd[3]/usr/ctxtDY_PATH").text = str(dest_dir)
    session.findById("wnd[3]/usr/ctxtDY_FILENAME").text = filename
    session.findById("wnd[3]/tbar[0]/btn[11]").press()
    session.findById("wnd[2]").close()
    session.findById("wnd[1]/tbar[0]/btn[0]").press()

    return dest_dir / filename


def export_all(session, notas: list[str], dest_dir: Path = c.DADOS_DIR) -> dict[str, Path | None]:
    """Single-system export, no fallback. Prefer export_all_with_fallback
    unless you specifically want to stay on one system."""
    results: dict[str, Path | None] = {}
    for nota in notas:
        try:
            results[nota] = export_relatorio_resumido(session, nota, dest_dir)
        except Exception:
            log.exception("Failed to export Rel. Resumido for Nota %s", nota)
            results[nota] = None
    return results


def export_all_with_fallback(
    notas: list[str],
    dest_dir: Path = c.DADOS_DIR,
    connections: list[dict] = c.SAP_CONNECTIONS,
    progress_callback=None,
    force_refresh: bool = False,
) -> dict[str, dict]:
    """Try every notification against `connections[0]` (current production,
    S4P). Anything that fails there for *any* reason -- not found, download
    error, whatever -- gets retried against `connections[1]` (historical,
    ERP), and so on through the rest of the list if you ever add more.

    `progress_callback(stage="sap", current, total, message)` is called
    after every single notification so a UI can show live progress instead
    of a frozen screen for what can be a long-running loop.

    `force_refresh=False` (default) skips any notification that already has
    a file sitting in `dest_dir` from a previous run instead of fetching it
    again -- this is what lets a batch resume after a crash partway through
    hundreds of notifications, instead of starting over from zero. Pass
    `force_refresh=True` to always re-fetch everything.

    Returns {nota: {"path": Path|None, "system": sid|None, "error": str|None}}
    """
    from . import consolidate

    results: dict[str, dict] = {
        nota: {"path": None, "system": None, "error": None} for nota in notas
    }
    total = len(notas)
    done = 0

    def _progress(message):
        if progress_callback:
            progress_callback("sap", done, total, message)

    remaining = list(notas)
    if not force_refresh:
        still_remaining = []
        for nota in remaining:
            cached = consolidate.find_export_file(nota, dest_dir)
            if cached is not None:
                results[nota] = {"path": cached, "system": "cache", "error": None}
                done += 1
                _progress(f"Nota {nota}: já baixada anteriormente, reaproveitando.")
            else:
                still_remaining.append(nota)
        remaining = still_remaining
        if done:
            log.info("%d notification(s) already downloaded, skipping re-fetch.", done)

    for connection in connections:
        if not remaining:
            break

        sid = connection["sid"]
        log.info(
            "Trying %d notification(s) against %s (%s)...",
            len(remaining), connection["name"], sid,
        )
        _progress(f"Conectando a {connection['name']} ({sid})...")
        session = connect_or_open_sap(connection)

        still_remaining = []
        for nota in remaining:
            _progress(f"[{sid}] Buscando Nota {nota}...")
            try:
                path = export_relatorio_resumido(session, nota, dest_dir)
                results[nota]["path"] = path
                results[nota]["system"] = sid
                results[nota]["error"] = None
                done += 1
                _progress(f"[{sid}] Nota {nota}: OK")
            except Exception as exc:
                log.warning("Nota %s not found/failed on %s: %s", nota, sid, exc)
                results[nota]["error"] = str(exc)
                still_remaining.append(nota)
                _progress(f"[{sid}] Nota {nota}: não encontrada, tentando próximo sistema...")

        close_sap_session(session)
        remaining = still_remaining

    if remaining:
        done = total  # loop is over either way; mark progress complete
        _progress(f"{len(remaining)} nota(s) não encontrada(s) em nenhum sistema.")
        log.warning(
            "%d notification(s) not found in any SAP system: %s", len(remaining), remaining
        )

    return results


def close_sap_session(session) -> None:
    """Equivalent of encerrar_ERP: send the /nex transaction code."""
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
    session.findById("wnd[0]").sendVKey(0)
