"""
Central configuration. Edit the paths below (or override with environment
variables of the same name) to match your environment.
"""
from __future__ import annotations
import os
from pathlib import Path

# --- Where SAP exports and this tool's outputs live ------------------------
DADOS_DIR = Path(os.environ.get("AUDIT_DADOS_DIR", r"C:\DADOS"))
OUTPUT_DIR = Path(os.environ.get("AUDIT_OUTPUT_DIR", r"C:\DADOS\saida"))

# --- Reference / lookup data shipped with this tool -------------------------
PACKAGE_DIR = Path(__file__).resolve().parent
DATA_DIR = PACKAGE_DIR / "data"
BD_UNC_CSV = DATA_DIR / "bd_unc.csv"
EXCECAO_XXFP_CSV = DATA_DIR / "excecao_xxfp.csv"

# --- SAP connection ----------------------------------------------------------
# Tried in order: current production system first, historical system as a
# fallback for notifications whose documents didn't migrate.
SAP_CONNECTIONS = [
    {"name": "3-S/4 on Hana - Produção", "sid": "S4P"},
    {"name": "3-SAP ERP - Produção Histórico", "sid": "ERP"},
]
SAP_LOGON_PATH = os.environ.get(
    "AUDIT_SAP_LOGON_PATH", r"C:\Program Files (x86)\SAP\FrontEnd\SAPgui\saplogon.exe"
)

# --- Column names used throughout (must match the "Rel. Resumido" export) ---
COL_NOTA = "Nota"
COL_PV = "P/V"
COL_UNC = "UNC"
COL_PONTO_VAO = "Ponto/Vão"
COL_DESCRICAO = "DESCRIÇÃO DE UNC"
COL_MNEMONICO = "MNEMONICO"
COL_OPERATION = "OPERATION"
COL_TIPO_MO = "TIPO MAO DE OBRA"
COL_TP_EXEC = "TP EXEC"
COL_PLANEJ = "PLANEJ"
COL_EXEC = "EXEC"
COL_FISCALIZ = "FISCALIZ"
COL_PONTO = "Ponto"  # identifier column used to group rows of the same physical point
COL_LINHA_ID = "linha_id"  # stable per-row id (Nota#position), for manual data entry & review persistence

# Columns copied verbatim from each SAP export (A8:L<last row> in the original)
SOURCE_COLUMNS = [
    COL_NOTA, COL_PV, COL_UNC, COL_PONTO_VAO, COL_DESCRICAO, "Coluna2",
    COL_MNEMONICO, COL_OPERATION, COL_TIPO_MO, COL_TP_EXEC, COL_PLANEJ, COL_EXEC,
]

RULE_COLUMNS = [
    "Divergência Fisc. X Executado",
    "MO Prim. Nua Ins/Ret",
    "MO Prim. Compac. Ins/Ret",
    "MO Sec. Nua Ins/Ret",
    "MO Sec. Multplex Ins/Ret",
    "MO Faca/Fus Nua Ins/Ret",
    "MO Faca/Fus Compac Ins/Ret",
    "RPS/RPE",
    "Vegetação",
    "xx/FP",
    "Reinst IP",
    "MO Cava/Solo Rochoso",
    "Aviso UnC",
    "Revisão LV",
    "Verificação Ponto",
    "Revisão LM",
    "E-Qt. Horas",
    "E-UnC Complem.",
    "E-Contagem MO",
    "MO Poste",
    "Amarração Indevida",
    "MO Cabo Indevida",
    "Conex LV Indevida",
    "EST TF LV MO/FIX Indevida",
    "MO Ramal indevida",
    "Segregação de Vão",
    "Duplicidade de Para-Raio",
    "MO Para-Raio",
    "MO Aterramento",
    "MO Espaçador",
    "Equipamento Reclassificado",
]
