"""
Replaces A_Geral.bas / Sub Atualizar_tudo(): the single entry point that
used to run every macro in sequence. Same steps, same order, but each step
is now a pure function you can call, test, and debug independently -- no
more stepping through VBA with F8.
"""
from __future__ import annotations
import logging
from pathlib import Path

import pandas as pd

from . import config as c
from . import consolidate
from . import error_list
from . import excel_export
from . import fiscaliz_store
from . import run_state
from .rules import apply_all_rules

log = logging.getLogger(__name__)


def run(
    notas: list[str],
    skip_sap: bool = False,
    reviewer: str | None = None,
    progress_callback=None,
    resume: bool = True,
) -> dict:
    """Runs the full pipeline and returns the key outputs in memory (nothing
    is written to disk here -- see main.py for that), so this is easy to
    call from a notebook, a test, a scheduled job, or the Streamlit app.

    Parameters
    ----------
    notas : list of notification numbers to process (was HOME!A2:A<last>)
    skip_sap : if True, assumes the "<Nota> - Relatório Resumido.xls" files
        are already sitting in config.DADOS_DIR (e.g. exported earlier, or
        by hand) and skips driving SAP GUI entirely.
    reviewer : name attached to the error list; defaults to the OS user.
    progress_callback : optional callable(stage: str, current: int, total: int,
        message: str) -- called throughout the run so a UI can show live
        progress instead of just tailing a log file.
    resume : if True (default), skips re-fetching any notification that
        already has an export file in config.DADOS_DIR -- lets a batch that
        crashed partway through pick up where it left off instead of
        re-hitting SAP for everything. Pass False to force a full refetch.
    """
    def _progress(stage, current, total, message):
        if progress_callback:
            progress_callback(stage, current, total, message)

    export_results = None
    if not skip_sap:
        from . import sap_extractor
        _progress("sap", 0, len(notas), "Conectando ao SAP...")
        export_results = sap_extractor.export_all_with_fallback(
            notas, progress_callback=progress_callback, force_refresh=not resume
        )
        not_found = [n for n, r in export_results.items() if r["path"] is None]
        if not_found:
            log.warning(
                "%d notification(s) had no document in any SAP system: %s",
                len(not_found), not_found,
            )
        historico = [n for n, r in export_results.items() if r["system"] == "ERP"]
        if historico:
            log.info(
                "%d notification(s) were only found in the historical system (ERP): %s",
                len(historico), historico,
            )

    _progress("consolidate", 0, 1, "Consolidando arquivos exportados...")
    consolidated = consolidate.consolidate(notas)
    if consolidated.empty:
        log.warning("No data consolidated -- nothing to analyze.")
        return {
            "consolidated": consolidated, "flagged": consolidated, "errors": consolidated,
            "export_results": export_results,
        }
    consolidated = fiscaliz_store.merge_into(consolidated)
    _progress("consolidate", 1, 1, f"{len(consolidated)} linhas consolidadas.")

    _progress("rules", 0, 1, f"Aplicando regras de auditoria a {len(consolidated)} linhas...")
    flagged = apply_all_rules(consolidated)
    _progress("rules", 1, 1, "Regras aplicadas.")

    _progress("errors", 0, 1, "Montando lista de erros...")
    errors = error_list.build_error_list(flagged, reviewer=reviewer)
    _progress("errors", 1, 1, f"{len(errors)} problemas encontrados.")

    n_alerts = (flagged["Alerta"] == "Sim").sum()
    log.info(
        "Done: %d rows, %d flagged (%.1f%%), %d individual issues.",
        len(flagged), n_alerts, 100 * n_alerts / len(flagged), len(errors),
    )

    run_state.save(consolidated, notas=notas, reviewer=reviewer, export_results=export_results)

    return {
        "consolidated": consolidated, "flagged": flagged, "errors": errors,
        "export_results": export_results,
    }


def recompute(
    consolidated: pd.DataFrame,
    reviewer: str | None = None,
    notas: list[str] | None = None,
    export_results: dict | None = None,
) -> dict:
    """Re-applies the rules + error list to an already-consolidated
    DataFrame -- used after a reviewer edits FISCALIZ values in the app, so
    the whole SAP export + consolidation step doesn't need to run again.
    Also re-saves the run state, so the edit isn't lost on a refresh."""
    flagged = apply_all_rules(consolidated)
    errors = error_list.build_error_list(flagged, reviewer=reviewer)
    run_state.save(consolidated, notas=notas, reviewer=reviewer, export_results=export_results)
    return {"consolidated": consolidated, "flagged": flagged, "errors": errors}


def save_outputs(results: dict, output_dir: Path = c.OUTPUT_DIR) -> dict[str, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    paths = {}
    for name, df in results.items():
        if not isinstance(df, pd.DataFrame):
            continue  # e.g. "export_results", which is a dict, not a table
        path = output_dir / f"{name}.xlsx"
        path.write_bytes(excel_export.styled_excel_bytes(df, sheet_name=name.capitalize()))
        paths[name] = path
    return paths
