"""
Styled Excel export shared by the dashboard's download buttons and the
CLI's saved output files, so every .xlsx leaving this tool reads like a
finished report instead of a raw pandas dump: bold frozen header,
autofilter, sane column widths, and 'Alerta'/'Status' columns colored with
Excel's own familiar green/red "good/bad" convention.

This is plain data (no formulas to keep correct across recalculation), so
the only requirement carried over from spreadsheet best practice here is a
professional font throughout.
"""
from __future__ import annotations
import io

import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

_FONT_NAME = "Arial"
_HEADER_FILL = PatternFill("solid", fgColor="1F4E78")
_HEADER_FONT = Font(name=_FONT_NAME, size=11, bold=True, color="FFFFFF")
_HEADER_BORDER = Border(bottom=Side(style="medium", color="1F4E78"))
_BODY_FONT = Font(name=_FONT_NAME, size=10)

_GOOD_FILL = PatternFill("solid", fgColor="C6EFCE")
_GOOD_FONT = Font(name=_FONT_NAME, size=10, color="006100")
_BAD_FILL = PatternFill("solid", fgColor="FFC7CE")
_BAD_FONT = Font(name=_FONT_NAME, size=10, color="9C0006")

_STATUS_COLORS = {
    "Pendente": (PatternFill("solid", fgColor="FFEB9C"), Font(name=_FONT_NAME, size=10, color="9C6500")),
    "Aprovado": (_GOOD_FILL, _GOOD_FONT),
    "Corrigido": (PatternFill("solid", fgColor="DDEBF7"), Font(name=_FONT_NAME, size=10, color="1F4E78")),
    "Não Aplicável": (PatternFill("solid", fgColor="E7E6E6"), Font(name=_FONT_NAME, size=10, color="595959")),
}

# Styling every cell's font is O(rows x cols) in openpyxl and gets slow past
# a few thousand rows -- skip it for big exports (header/filter/widths/
# color-coding still apply, which matter more anyway) rather than make a
# large download take tens of seconds.
_MAX_ROWS_FOR_BODY_FONT = 5000


def styled_excel_bytes(df: pd.DataFrame, sheet_name: str = "Dados") -> bytes:
    """Writes df to .xlsx bytes with header styling, freeze panes, an
    autofilter, auto-sized columns, and color-coded Alerta/Status columns
    when present."""
    if df.empty:
        buf = io.BytesIO()
        with pd.ExcelWriter(buf, engine="openpyxl") as writer:
            df.to_excel(writer, index=False, sheet_name=sheet_name)
        return buf.getvalue()

    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name=sheet_name)
    buf.seek(0)

    wb = load_workbook(buf)
    ws = wb[sheet_name]
    n_rows, n_cols = df.shape

    for col_idx in range(1, n_cols + 1):
        cell = ws.cell(row=1, column=col_idx)
        cell.font = _HEADER_FONT
        cell.fill = _HEADER_FILL
        cell.alignment = Alignment(vertical="center")
        cell.border = _HEADER_BORDER
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    ws.row_dimensions[1].height = 20

    for col_idx, col_name in enumerate(df.columns, start=1):
        series = df.iloc[:, col_idx - 1].astype(str)
        max_len = max([len(str(col_name))] + ([series.str.len().max()] if len(series) else [0]))
        ws.column_dimensions[get_column_letter(col_idx)].width = min(max(max_len + 2, 10), 60)

    if n_rows <= _MAX_ROWS_FOR_BODY_FONT:
        for row in ws.iter_rows(min_row=2, max_row=n_rows + 1, max_col=n_cols):
            for cell in row:
                cell.font = _BODY_FONT

    if "Alerta" in df.columns:
        col_idx = df.columns.get_loc("Alerta") + 1
        for row_idx, value in enumerate(df["Alerta"], start=2):
            if value in ("Sim", "Não"):
                cell = ws.cell(row=row_idx, column=col_idx)
                cell.fill, cell.font = (_BAD_FILL, _BAD_FONT) if value == "Sim" else (_GOOD_FILL, _GOOD_FONT)

    if "Status" in df.columns:
        col_idx = df.columns.get_loc("Status") + 1
        for row_idx, value in enumerate(df["Status"], start=2):
            colors = _STATUS_COLORS.get(value)
            if colors:
                cell = ws.cell(row=row_idx, column=col_idx)
                cell.fill, cell.font = colors

    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()
