"""
Persists the FISCALIZ quantity a reviewer enters for each row.

FISCALIZ never comes from SAP -- in the original workbook someone typed it
directly into column N of the consolidated sheet after every export, and it
was gone the moment the workbook was closed without saving (or overwritten
the next time the macro re-consolidated). Keying by the row's stable
`linha_id` (Nota#position) means a value entered here survives both.
"""
from __future__ import annotations
import sqlite3
from pathlib import Path
from datetime import datetime

import pandas as pd

from . import config as c

DB_PATH = Path(c.OUTPUT_DIR) / "fiscaliz_entries.db"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS fiscaliz (
    linha_id TEXT PRIMARY KEY,
    valor TEXT NOT NULL,
    reviewer TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL
);
"""


def _connect(db_path: Path = DB_PATH) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.execute(_SCHEMA)
    return conn


def load_all(db_path: Path = DB_PATH) -> pd.DataFrame:
    with _connect(db_path) as conn:
        return pd.read_sql_query("SELECT * FROM fiscaliz", conn)


def upsert_bulk(rows: list[dict], db_path: Path = DB_PATH) -> None:
    """rows: [{"linha_id": ..., "valor": ..., "reviewer": ...}, ...]"""
    with _connect(db_path) as conn:
        conn.executemany(
            """
            INSERT INTO fiscaliz (linha_id, valor, reviewer, updated_at)
            VALUES (:linha_id, :valor, :reviewer, :updated_at)
            ON CONFLICT(linha_id) DO UPDATE SET
                valor=excluded.valor,
                reviewer=excluded.reviewer,
                updated_at=excluded.updated_at
            """,
            [
                {**r, "updated_at": datetime.now().isoformat(timespec="seconds")}
                for r in rows
            ],
        )


def merge_into(consolidated: pd.DataFrame, db_path: Path = DB_PATH) -> pd.DataFrame:
    """Fills in any previously-entered FISCALIZ values by linha_id, leaving
    rows nobody has reviewed yet blank (same as a fresh consolidation)."""
    stored = load_all(db_path)
    df = consolidated.copy()
    if stored.empty:
        return df
    valor_map = stored.set_index("linha_id")["valor"]
    has_value = df[c.COL_LINHA_ID].isin(valor_map.index)
    df.loc[has_value, c.COL_FISCALIZ] = df.loc[has_value, c.COL_LINHA_ID].map(valor_map)
    return df
