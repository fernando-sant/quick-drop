"""Replaces E_lista_de_erros.bas: turns the wide table of rule-flag columns
into one row per flagged issue, which is what a reviewer actually wants to
work through (the VBA version wrote this to the HOME sheet columns G:O)."""
from __future__ import annotations
from datetime import date
import getpass

import pandas as pd

from . import config as c


def build_error_list(df: pd.DataFrame, reviewer: str | None = None) -> pd.DataFrame:
    reviewer = reviewer or getpass.getuser()
    today = date.today().isoformat()

    id_cols = [c.COL_NOTA, c.COL_PV, c.COL_UNC, c.COL_DESCRICAO, c.COL_MNEMONICO]
    melted = df.melt(
        id_vars=id_cols,
        value_vars=c.RULE_COLUMNS,
        var_name="Nome Verificação",
        value_name="Resultado Alerta",
    )
    melted = melted[melted["Resultado Alerta"] != ""].copy()

    melted = melted.rename(columns={
        c.COL_NOTA: "Nota",
        c.COL_PV: "Ponto",
        c.COL_UNC: "UnC",
        c.COL_DESCRICAO: "Descrição",
    })
    melted["Usuário Avaliador"] = reviewer
    melted["Data"] = today

    return melted[
        ["Nota", "Ponto", "UnC", "Descrição", "Nome Verificação",
         "Resultado Alerta", "Usuário Avaliador", "Data"]
    ].reset_index(drop=True)
