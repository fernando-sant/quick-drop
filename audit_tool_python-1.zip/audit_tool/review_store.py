"""
Persists reviewer decisions on flagged issues (status + comment) across app
restarts and pipeline re-runs -- something the original workbook had no
equivalent of; a reviewer's only record was whatever they manually typed
into the HOME sheet's "Ação" column, which got overwritten the next time
someone ran the macro.

Backed by a single SQLite file so it works with zero setup (no server) and
survives being copied alongside the rest of the tool's output.
"""
from __future__ import annotations
import sqlite3
from pathlib import Path
from datetime import datetime

import pandas as pd

from . import config as c

DB_PATH = Path(c.OUTPUT_DIR) / "review_status.db"

STATUSES = ["Pendente", "Aprovado", "Corrigido", "Não Aplicável"]

_SCHEMA = """
CREATE TABLE IF NOT EXISTS review (
    nota TEXT NOT NULL,
    ponto TEXT NOT NULL,
    unc TEXT NOT NULL,
    rule TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Pendente',
    comment TEXT NOT NULL DEFAULT '',
    reviewer TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL,
    PRIMARY KEY (nota, ponto, unc, rule)
);
"""


def _connect(db_path: Path = DB_PATH) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.execute(_SCHEMA)
    return conn


def load_all(db_path: Path = DB_PATH) -> pd.DataFrame:
    with _connect(db_path) as conn:
        return pd.read_sql_query("SELECT * FROM review", conn)


def upsert(nota, ponto, unc, rule, status, comment, reviewer, db_path: Path = DB_PATH) -> None:
    with _connect(db_path) as conn:
        conn.execute(
            """
            INSERT INTO review (nota, ponto, unc, rule, status, comment, reviewer, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(nota, ponto, unc, rule) DO UPDATE SET
                status=excluded.status,
                comment=excluded.comment,
                reviewer=excluded.reviewer,
                updated_at=excluded.updated_at
            """,
            (str(nota), str(ponto), str(unc), str(rule), status, comment, reviewer,
             datetime.now().isoformat(timespec="seconds")),
        )


def upsert_bulk(rows: list[dict], db_path: Path = DB_PATH) -> None:
    with _connect(db_path) as conn:
        conn.executemany(
            """
            INSERT INTO review (nota, ponto, unc, rule, status, comment, reviewer, updated_at)
            VALUES (:nota, :ponto, :unc, :rule, :status, :comment, :reviewer, :updated_at)
            ON CONFLICT(nota, ponto, unc, rule) DO UPDATE SET
                status=excluded.status,
                comment=excluded.comment,
                reviewer=excluded.reviewer,
                updated_at=excluded.updated_at
            """,
            [
                {**r, "updated_at": datetime.now().isoformat(timespec="seconds")}
                for r in rows
            ],
        )


def merge_into_errors(errors: pd.DataFrame, db_path: Path = DB_PATH) -> pd.DataFrame:
    """Left-joins persisted status/comment/reviewer onto a freshly-built
    error list, defaulting unseen issues to 'Pendente'."""
    review = load_all(db_path)
    if review.empty:
        out = errors.copy()
        out["Status"] = "Pendente"
        out["Comentário"] = ""
        out["Revisado Por"] = ""
        out["Atualizado Em"] = ""
        return out

    merged = errors.merge(
        review.rename(columns={
            "nota": "Nota", "ponto": "Ponto", "unc": "UnC", "rule": "Nome Verificação",
            "status": "Status", "comment": "Comentário", "reviewer": "Revisado Por",
            "updated_at": "Atualizado Em",
        }),
        on=["Nota", "Ponto", "UnC", "Nome Verificação"],
        how="left",
    )
    for col, default in [
        ("Status", "Pendente"), ("Comentário", ""), ("Revisado Por", ""), ("Atualizado Em", ""),
    ]:
        merged[col] = merged[col].fillna(default)
    return merged
