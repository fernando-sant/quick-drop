"""
audit_tool
==========
Python replacement for the "Análise_Relatório_Resumido" Excel/VBA workbook.

Modules:
    config       -- paths, constants, notification list source
    lookups      -- BD_UnC / Exceção xx-FP reference tables
    consolidate  -- merge per-notification "Rel. Resumido" exports into one table
    rules        -- the ~30 audit rules, vectorized with pandas
    pipeline     -- orchestrates consolidate -> rules -> error list -> export
    sap_extractor-- SAP GUI scripting automation (Windows + SAP GUI only)
"""
