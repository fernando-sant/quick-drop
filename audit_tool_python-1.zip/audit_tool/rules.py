"""
Audit rule engine.

Each function below is a direct, documented translation of one column/formula
from the 'Aplicar_formulas' VBA macro (module D_Formulas.bas) in the original
workbook. Where the original formula's cell-relative (R1C1) references were
ambiguous, self-referential, or looked like a copy/paste artifact (columns
'EST TF LV MO/FIX Indevida' and 'MO Ramal indevida' in particular), this
version implements the rule the way its name and the 'Explicação Regras'
sheet describe it, and the discrepancy is called out in validate.py.

All rules are vectorized: no per-row Excel-style loops. On the ~12k row
sample from the original workbook this runs in well under a second, versus
the multi-minute AutoFill + PasteSpecial dance the macro performed.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

from . import config as c
from . import lookups


def _weighted_group_sum(df: pd.DataFrame, mask: pd.Series, group_cols: list[str],
                         weight_col: str = c.COL_FISCALIZ) -> pd.Series:
    """Sum `weight_col` over rows where `mask` is True, within each group
    defined by `group_cols`, broadcast back to every row of that group.
    This is the vectorized equivalent of the workbook's repeated
    SUMPRODUCT((Nota=...)*(Ponto=...)*(condition)*(FISCALIZ)) formulas.
    """
    weighted = df[weight_col].where(mask, 0)
    return weighted.groupby([df[g] for g in group_cols]).transform("sum")


def _group_count(df: pd.DataFrame, mask: pd.Series, group_cols: list[str]) -> pd.Series:
    """Unweighted row count within each group, for the COUNTIFS-style rules."""
    return mask.groupby([df[g] for g in group_cols]).transform("sum")


def _ins_ret_rule(df: pd.DataFrame, unc_code: int, message: str) -> pd.Series:
    """Shared logic behind the six 'MO ... Ins/Ret' rules and 'MO Poste':
    flags a UnC when the same (Nota, Ponto) combination has both an
    INSTALAR and a RETIRAR budgeted for it (should have been SUBST_I/R).
    """
    is_code = df[c.COL_UNC] == unc_code
    weighted = _weighted_group_sum(
        df,
        is_code & df[c.COL_OPERATION].isin(["INSTALAR", "RETIRAR"]),
        [c.COL_NOTA, c.COL_PV],
    )
    row_qualifies = is_code & (df[c.COL_FISCALIZ] != 0)
    return np.where(row_qualifies & (weighted >= 2), message, "")


def rule_divergencia_fisc_executado(df: pd.DataFrame) -> pd.Series:
    exec_blank = df[c.COL_EXEC].isna() | (df[c.COL_EXEC] == "")
    diverges = df[c.COL_FISCALIZ] != df[c.COL_EXEC]
    return np.where(~exec_blank & diverges, "Divergência Fiscalizado x Executado", "")


def rule_mo_prim_nua_ins_ret(df):
    return _ins_ret_rule(df, 30801, "Verificar Operação")


def rule_mo_prim_compac_ins_ret(df):
    return _ins_ret_rule(df, 31501, "Verificar Operação")


def rule_mo_sec_nua_ins_ret(df):
    return _ins_ret_rule(df, 30803, "Verificar Operação")


def rule_mo_sec_multiplex_ins_ret(df):
    return _ins_ret_rule(df, 30804, "Verificar Operação")


def rule_mo_faca_fus_nua_ins_ret(df):
    return _ins_ret_rule(df, 30301, "Verificar Operação")


def rule_mo_faca_fus_compac_ins_ret(df):
    return _ins_ret_rule(df, 30502, "Verificar Operação")


def rule_mo_poste(df: pd.DataFrame) -> pd.Series:
    return _ins_ret_rule(df, 30013, "Verificar Operação - correto (SUBST_I/R)")


def rule_rps_rpe(df: pd.DataFrame) -> pd.Series:
    codes = [2223, 2250]
    is_code = df[c.COL_UNC].isin(codes)
    weighted = _weighted_group_sum(
        df, is_code & (df[c.COL_OPERATION] == "INSTALAR"), [c.COL_NOTA, c.COL_PV]
    )
    return np.where(is_code & (weighted >= 3), "Excesso RPS/RPE", "")


def rule_vegetacao(df: pd.DataFrame) -> pd.Series:
    codes = [6352, 7707, 7701, 2221]
    is_code = df[c.COL_UNC].isin(codes)
    weighted = _weighted_group_sum(df, is_code, [c.COL_NOTA, c.COL_PV])
    return np.where(is_code & (weighted >= 5), "Ver Vegetação", "")


def rule_xx_fp(df: pd.DataFrame, excecao_ids: set) -> pd.Series:
    not_exempt = ~df[c.COL_UNC].isin(excecao_ids)
    text_match = df[c.COL_DESCRICAO].str.contains("XX|FP", case=False, na=False, regex=True)
    op_match = df[c.COL_OPERATION].isin(["INSTALAR", "SUBST_I"])
    return np.where(not_exempt & text_match & op_match, "xx/FP", "")


def rule_reinst_ip(df: pd.DataFrame) -> pd.Series:
    is_code = df[c.COL_UNC] == 42022
    weighted = _weighted_group_sum(df, is_code, [c.COL_NOTA, c.COL_PV])
    count_30013 = _group_count(df, df[c.COL_UNC] == 30013, [c.COL_NOTA, c.COL_PV])
    return np.where(
        is_code & (weighted >= 1) & (count_30013 == 0),
        "Reinst. em Despesa - Orçar MO de Conexão",
        "",
    )


def rule_mo_cava_solo_rochoso(df: pd.DataFrame) -> pd.Series:
    codes = [2224, 2222]
    is_code = df[c.COL_UNC].isin(codes)
    weighted = _weighted_group_sum(df, is_code, [c.COL_NOTA, c.COL_PV])
    return np.where(is_code & (weighted >= 1), "Cava/Solo Rochoso", "")


def rule_aviso_unc(df: pd.DataFrame, bd_unc: pd.DataFrame) -> pd.Series:
    merged = df[[c.COL_UNC]].merge(
        bd_unc[["ID UnC", "Erro"]], left_on=c.COL_UNC, right_on="ID UnC", how="left"
    )
    erro = merged["Erro"].fillna("")
    # Excel string comparison ("=") is case-insensitive, so "Ok"/"ok"/"OK"
    # in the source data all count as "no warning" here too.
    is_ok = erro.str.strip().str.upper() == "OK"
    return np.where((erro != "") & ~is_ok, erro, "")


def rule_revisao_lv(df: pd.DataFrame, bd_unc: pd.DataFrame) -> pd.Series:
    merged = df[[c.COL_UNC]].merge(
        bd_unc[["ID UnC", "LV"]], left_on=c.COL_UNC, right_on="ID UnC", how="left"
    )
    lv_note = merged["LV"].fillna("")
    not_lm = df[c.COL_TP_EXEC] != "LM"
    return np.where(not_lm & (lv_note != ""), lv_note.values, "")


def rule_verificacao_ponto(df: pd.DataFrame, bd_unc: pd.DataFrame) -> pd.Series:
    merged = df[[c.COL_UNC]].merge(
        bd_unc[["ID UnC", "Ponto"]], left_on=c.COL_UNC, right_on="ID UnC", how="left"
    )
    ponto_note = merged["Ponto"].fillna("")
    is_ponto = df[c.COL_PV].str.contains("P", case=True, na=False, regex=False)
    return np.where(is_ponto & (ponto_note != ""), ponto_note.values, "")


def rule_revisao_lm(df: pd.DataFrame, bd_unc: pd.DataFrame) -> pd.Series:
    merged = df[[c.COL_UNC]].merge(
        bd_unc[["ID UnC", "LM"]], left_on=c.COL_UNC, right_on="ID UnC", how="left"
    )
    lm_note = merged["LM"].fillna("")
    not_lv = df[c.COL_TP_EXEC] != "LV"
    return np.where(not_lv & (lm_note != ""), lm_note.values, "")


def rule_e_qt_horas(df: pd.DataFrame) -> pd.Series:
    codes = [40200, 40201]
    is_code = df[c.COL_UNC].isin(codes)
    weighted = _weighted_group_sum(df, is_code, [c.COL_NOTA, c.COL_PV])
    return np.where(is_code & (weighted >= 12), "Apenas Emergência - Limite de Horas", "")


def rule_e_unc_complementar(df: pd.DataFrame) -> pd.Series:
    """NOTE: the original VBA formula references the 'P/V' column here
    (RC[-31] resolves to column C), not 'TIPO MAO DE OBRA' as the rule's
    plain-language description ("UnC Complementar") would suggest. Kept
    literal to the original formula; verify against your real data --
    see README 'Rules needing verification'."""
    codes = [40200, 40201]
    is_code = df[c.COL_UNC].isin(codes)
    not_uc_compl = df[c.COL_PV] != "UC Compl"
    return np.where(
        is_code & not_uc_compl, "Apenas Emergência - Fora de UNC Complem.", ""
    )


def rule_e_contagem_mo(df: pd.DataFrame) -> pd.Series:
    codes = [40200, 40201]
    is_code = df[c.COL_UNC].isin(codes)
    count = _group_count(df, is_code, [c.COL_NOTA, c.COL_PV])
    return np.where(is_code & (count >= 3), "Apenas Emergência - Excesso de Linhas", "")


def rule_amarracao_indevida(df: pd.DataFrame) -> pd.Series:
    is_code = df[c.COL_UNC] == 30407
    weighted = _weighted_group_sum(
        df,
        df[c.COL_UNC].isin([30801, 31501])
        & df[c.COL_OPERATION].isin(["INSTALAR", "SUBST_I"])
        & (df[c.COL_TP_EXEC] == "LV"),
        [c.COL_NOTA, c.COL_PV],
    )
    return np.where(is_code & (weighted >= 1), "Amarração Indevida - MO em LV!", "")


def rule_mo_cabo_indevida(df: pd.DataFrame) -> pd.Series:
    is_code = df[c.COL_UNC].isin([93408, 93552])
    weighted = _weighted_group_sum(
        df,
        df[c.COL_UNC].isin([30801, 31501, 30802])
        & df[c.COL_OPERATION].isin(["INSTALAR", "SUBST_I"])
        & (df[c.COL_TP_EXEC] == "LV"),
        [c.COL_NOTA, c.COL_PV],
    )
    return np.where(is_code & (weighted >= 1), "MO Cabo já inclusa na MO estrutura LV!", "")


def rule_conex_lv_indevida(df: pd.DataFrame) -> pd.Series:
    is_code = df[c.COL_UNC].isin([6434, 6430])
    weighted = _weighted_group_sum(
        df,
        df[c.COL_UNC].isin([30801, 31501])
        & df[c.COL_OPERATION].isin(["INSTALAR", "SUBST_I"])
        & (df[c.COL_TP_EXEC] == "LV"),
        [c.COL_NOTA, c.COL_PV],
    )
    return np.where(is_code & (weighted >= 1), "Conex LV Indevida", "")


def rule_est_tf_lv_mo_fix_indevida(df: pd.DataFrame) -> pd.Series:
    """NOTE: the original formula grouped by the row 6 lines above the
    current one (R[-6]C...) instead of the current row's own Nota/Ponto --
    almost certainly an AutoFill artifact/bug rather than intended logic.
    This version groups by the current row's (Nota, Ponto), matching every
    other 'Indevida' rule. See README."""
    codes = [
        6346, 6400, 83586, 83616, 83700, 83641, 83713, 83706, 83753, 83580,
        83610, 83683, 83689, 83630, 83587, 83617, 8482, 83611, 83604, 83631,
    ]
    is_code = df[c.COL_UNC].isin(codes)
    weighted = _weighted_group_sum(
        df,
        df[c.COL_UNC].isin([31502, 30301])
        & df[c.COL_OPERATION].isin(["INSTALAR", "SUBST_I"])
        & (df[c.COL_TP_EXEC] == "LV"),
        [c.COL_NOTA, c.COL_PV],
    )
    return np.where(is_code & (weighted >= 1), "EST TF LV MO ou FIX Indevida", "")


def rule_mo_ramal_indevida(df: pd.DataFrame) -> pd.Series:
    is_code = df[c.COL_UNC] == 31101
    is_reinstal = df[c.COL_OPERATION] == "REINSTAL"
    return np.where(is_code & is_reinstal, "Revisar para UnC 31103", "")


def rule_segregacao_de_vao(df: pd.DataFrame) -> pd.Series:
    is_vao_code = df[c.COL_PV].str.contains("V", case=True, na=False, regex=False)
    exec_below_planej = (df[c.COL_EXEC] - df[c.COL_PLANEJ]) < 0
    is_vao_class = df[c.COL_PONTO_VAO] == "Vão"
    count = _group_count(
        df, pd.Series(True, index=df.index), [c.COL_NOTA, c.COL_PV, c.COL_UNC, c.COL_OPERATION]
    )
    mask = is_vao_code & exec_below_planej & is_vao_class
    return np.where(
        mask & (count <= 1),
        "Segreg. de Vão - ver se possui adicional equivalente neste vão",
        "",
    )


def rule_duplicidade_para_raio(df: pd.DataFrame) -> pd.Series:
    codes = [17160, 17162, 1015]
    is_code = df[c.COL_UNC].isin(codes)
    count = _group_count(df, is_code, [c.COL_NOTA, c.COL_PV])
    return np.where(is_code, np.where(count > 1, "Duplicidade de Material no ponto", "OK"), "")


def rule_mo_para_raio(df: pd.DataFrame) -> pd.Series:
    is_code = df[c.COL_UNC] == 1015
    count = _group_count(
        df, df[c.COL_UNC] == 31201, [c.COL_NOTA, c.COL_PV, c.COL_OPERATION]
    )
    return np.where(is_code & (count > 0), "MO em Duplicidade, Procurar UNC 31201", "")


def rule_mo_aterramento(df: pd.DataFrame) -> pd.Series:
    codes = [
        46092, 46094, 36092, 36094, 75664, 75562, 9050, 18076, 18177, 56931,
        65534, 55100, 55001, 86062, 86063, 85191, 85243, 85245, 95534, 92407,
        81346, 75632, 75633, 75634, 75650, 75661, 75560, 75563, 75570, 75571,
        75578, 75534, 9063, 9065, 2405, 2406, 26034, 26092, 26093, 26095,
        11034, 15634, 15644, 15650, 15651,
    ]
    is_code = df[c.COL_UNC].isin(codes) & (df[c.COL_OPERATION] == "INSTALAR")
    count = _group_count(
        df, df[c.COL_UNC] == 6354, [c.COL_NOTA, c.COL_PV, c.COL_OPERATION]
    )
    return np.where(is_code & (count > 0), "MO Indevida - (Procurar UnC 6354)", "")


def rule_mo_espacador(df: pd.DataFrame) -> pd.Series:
    is_code = (df[c.COL_UNC] == 93433) & (df[c.COL_OPERATION] == "INSTALAR")
    group_cols = [c.COL_NOTA, c.COL_PV, c.COL_OPERATION]
    sum_93433 = _weighted_group_sum(df, df[c.COL_UNC] == 93433, group_cols)
    sum_31503 = _weighted_group_sum(df, df[c.COL_UNC] == 31503, group_cols)
    return np.where(
        is_code & (sum_93433 != sum_31503),
        "Divergência na Quantidade de MO (UnC-31503)",
        "",
    )


def rule_equipamento_reclassificado(df: pd.DataFrame) -> pd.Series:
    """The original workbook has no visible formula for this column in the
    extracted VBA -- it may be entered another way (e.g. a separate lookup
    against the 'Transformadores' sheet not covered here). Left as a stub
    returning blank; see README."""
    return np.full(len(df), "", dtype=object)


def apply_all_rules(df: pd.DataFrame) -> pd.DataFrame:
    """Run every rule and return `df` with the rule columns filled in,
    plus a derived 'Alerta' ('Sim'/'Não') column -- the Python equivalent
    of the whole 'Aplicar_formulas' macro."""
    df = df.copy()

    # Types: FISCALIZ/PLANEJ/EXEC are numeric quantities; blanks -> 0/NaN as
    # the workbook treated them.
    for col in (c.COL_FISCALIZ, c.COL_PLANEJ, c.COL_EXEC):
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df[c.COL_UNC] = pd.to_numeric(df[c.COL_UNC], errors="coerce")

    bd_unc = lookups.load_bd_unc()
    excecao_ids = lookups.load_excecao_xxfp()

    # Ponto/Vão classification (was column E in the workbook)
    df[c.COL_PONTO_VAO] = np.select(
        [
            df[c.COL_PV].str.contains("P", case=True, na=False, regex=False),
            df[c.COL_PV].str.contains("V", case=True, na=False, regex=False),
        ],
        ["Ponto", "Vão"],
        default="",
    )

    df["Divergência Fisc. X Executado"] = rule_divergencia_fisc_executado(df)
    df["MO Prim. Nua Ins/Ret"] = rule_mo_prim_nua_ins_ret(df)
    df["MO Prim. Compac. Ins/Ret"] = rule_mo_prim_compac_ins_ret(df)
    df["MO Sec. Nua Ins/Ret"] = rule_mo_sec_nua_ins_ret(df)
    df["MO Sec. Multplex Ins/Ret"] = rule_mo_sec_multiplex_ins_ret(df)
    df["MO Faca/Fus Nua Ins/Ret"] = rule_mo_faca_fus_nua_ins_ret(df)
    df["MO Faca/Fus Compac Ins/Ret"] = rule_mo_faca_fus_compac_ins_ret(df)
    df["RPS/RPE"] = rule_rps_rpe(df)
    df["Vegetação"] = rule_vegetacao(df)
    df["xx/FP"] = rule_xx_fp(df, excecao_ids)
    df["Reinst IP"] = rule_reinst_ip(df)
    df["MO Cava/Solo Rochoso"] = rule_mo_cava_solo_rochoso(df)
    df["Aviso UnC"] = rule_aviso_unc(df, bd_unc)
    df["Revisão LV"] = rule_revisao_lv(df, bd_unc)
    df["Verificação Ponto"] = rule_verificacao_ponto(df, bd_unc)
    df["Revisão LM"] = rule_revisao_lm(df, bd_unc)
    df["E-Qt. Horas"] = rule_e_qt_horas(df)
    df["E-UnC Complem."] = rule_e_unc_complementar(df)
    df["E-Contagem MO"] = rule_e_contagem_mo(df)
    df["MO Poste"] = rule_mo_poste(df)
    df["Amarração Indevida"] = rule_amarracao_indevida(df)
    df["MO Cabo Indevida"] = rule_mo_cabo_indevida(df)
    df["Conex LV Indevida"] = rule_conex_lv_indevida(df)
    df["EST TF LV MO/FIX Indevida"] = rule_est_tf_lv_mo_fix_indevida(df)
    df["MO Ramal indevida"] = rule_mo_ramal_indevida(df)
    df["Segregação de Vão"] = rule_segregacao_de_vao(df)
    df["Duplicidade de Para-Raio"] = rule_duplicidade_para_raio(df)
    df["MO Para-Raio"] = rule_mo_para_raio(df)
    df["MO Aterramento"] = rule_mo_aterramento(df)
    df["MO Espaçador"] = rule_mo_espacador(df)
    df["Equipamento Reclassificado"] = rule_equipamento_reclassificado(df)

    any_flag = (df[c.RULE_COLUMNS] != "").any(axis=1)
    df["Alerta"] = np.where(any_flag, "Sim", "Não")

    return df
