"""
Replaces C_Consolidar_Resumido.bas + Y_Limpar_Dados.bas.

Reads every SAP export ("<Nota> - Relatório Resumido.xls[x]") from
config.DADOS_DIR and stacks them into one DataFrame, tagging each block of
rows with the notification number it came from -- exactly what the VBA loop
did with Workbooks.Open + copy/paste, but without opening Excel at all.
"""
from __future__ import annotations
import logging
from pathlib import Path

import pandas as pd

from . import config as c

log = logging.getLogger(__name__)


def load_notification_list(home_path: Path) -> list[str]:
    """The 'Lista de Notas para Busca' column from the HOME sheet: which
    notification numbers to process this run."""
    df = pd.read_excel(home_path, sheet_name="Home", usecols="A", skiprows=1, header=None)
    return df.iloc[:, 0].dropna().astype(str).str.strip().tolist()


def find_export_file(nota: str, dest_dir: Path | None = None) -> Path | None:
    """Public so sap_extractor can check 'has this nota already been
    downloaded?' before hitting SAP again -- used to resume an interrupted
    batch without re-fetching everything."""
    dest_dir = dest_dir or c.DADOS_DIR
    matches = sorted(dest_dir.glob(f"{nota} - Relatório Resumido.xls*"))
    if not matches:
        matches = sorted(dest_dir.glob(f"{nota}-RelResumido*.xls*"))
    return matches[0] if matches else None


def consolidate(notas: list[str]) -> pd.DataFrame:
    """Read each notification's exported 'Rel. Resumido' sheet (rows 8+ of
    columns A:L, matching the original wsOrigem.Range("A8:L...") copy) and
    stack them, filling in the Nota column exactly like
    C_Consolidar_Resumido.bas did.
    """
    frames = []
    missing = []
    for nota in notas:
        path = find_export_file(nota)
        if path is None:
            missing.append(nota)
            log.warning("No export file found for Nota %s in %s", nota, c.DADOS_DIR)
            continue

        raw = pd.read_excel(path, sheet_name="Rel. Resumido", header=None, skiprows=7)
        raw = raw.iloc[:, :12]
        raw.columns = c.SOURCE_COLUMNS
        raw[c.COL_NOTA] = nota
        frames.append(raw)

    if missing:
        log.warning("%d notification(s) had no export file: %s", len(missing), missing)

    if not frames:
        return pd.DataFrame(columns=c.SOURCE_COLUMNS)

    consolidated = pd.concat(frames, ignore_index=True)
    # Drop fully-blank trailing rows, same effect as the sheet's used-range
    # padding in the original workbook.
    consolidated = consolidated.dropna(how="all").reset_index(drop=True)

    # FISCALIZ is NOT part of the SAP export (A8:L only) -- a reviewer fills
    # it in by hand after consolidation, same as in the original workbook.
    # Give every row a stable id so that manual entry, and any review
    # decisions made against it, survive being re-consolidated later.
    consolidated[c.COL_LINHA_ID] = (
        consolidated[c.COL_NOTA].astype(str) + "#" +
        consolidated.groupby(c.COL_NOTA).cumcount().astype(str)
    )
    consolidated[c.COL_FISCALIZ] = ""

    return consolidated
