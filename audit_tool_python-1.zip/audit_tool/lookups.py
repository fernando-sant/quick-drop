"""Loads the reference tables the VBA workbook stored in the 'BD_UnC' and
'Exceção xx-FP' sheets. These ship as CSV inside audit_tool/data/ so the
tool works without a live connection to the original workbook.
"""
from __future__ import annotations
import pandas as pd
from . import config


def load_bd_unc() -> pd.DataFrame:
    """Reference table describing every 'Unidade de Construção' (UnC) code.

    Relevant columns used by the audit rules:
        'ID UnC'  -- the UnC code (join key)
        'Erro'    -- free-text warning for this UnC ("OK" = no warning)
        'Ponto'   -- non-blank => flags budgeting this UnC at a "Ponto"
        'LV'      -- non-blank => review note when this UnC is in LV
        'LM'      -- non-blank => review note when this UnC is in LM
    """
    df = pd.read_csv(config.BD_UNC_CSV, dtype={"ID UnC": "float64"}, low_memory=False)
    df["ID UnC"] = df["ID UnC"].astype("Int64")
    return df


def load_excecao_xxfp() -> set:
    """Set of UnC codes exempted from the 'xx/FP' naming-convention rule."""
    df = pd.read_csv(config.EXCECAO_XXFP_CSV, dtype={"ID UnC": "float64"})
    return set(df["ID UnC"].dropna().astype("Int64"))
