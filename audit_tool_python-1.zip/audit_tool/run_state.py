"""
Persists the consolidated result of the last pipeline run so the dashboard
can restore it on startup. A browser refresh, an accidentally-closed tab,
or the app process itself restarting no longer means re-running SAP
extraction and consolidation from scratch -- only the (cheap, sub-second)
rule application needs to happen again, from data already on disk.
"""
from __future__ import annotations
import json
from datetime import datetime
from pathlib import Path

import pandas as pd

from . import config as c

STATE_DIR = Path(c.OUTPUT_DIR) / "last_run"
CONSOLIDATED_PATH = STATE_DIR / "consolidated.csv"
META_PATH = STATE_DIR / "meta.json"


def save(
    consolidated: pd.DataFrame,
    notas: list[str] | None = None,
    reviewer: str | None = None,
    export_results: dict | None = None,
) -> None:
    if consolidated.empty:
        return
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    consolidated.to_csv(CONSOLIDATED_PATH, index=False)

    if notas is None:
        notas = sorted(consolidated[c.COL_NOTA].dropna().unique().tolist())

    safe_export_results = None
    if export_results is not None:
        safe_export_results = {
            nota: {
                "path": str(r["path"]) if r.get("path") else None,
                "system": r.get("system"),
                "error": r.get("error"),
            }
            for nota, r in export_results.items()
        }

    META_PATH.write_text(
        json.dumps(
            {
                "notas": notas,
                "reviewer": reviewer,
                "export_results": safe_export_results,
                "saved_at": datetime.now().isoformat(timespec="seconds"),
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


def load() -> dict | None:
    """Returns {"consolidated": df, "notas": [...], "reviewer": str|None,
    "export_results": dict|None, "saved_at": iso-string} or None if there's
    no saved run yet."""
    if not CONSOLIDATED_PATH.exists() or not META_PATH.exists():
        return None
    consolidated = pd.read_csv(CONSOLIDATED_PATH, dtype=str, keep_default_na=False)
    # A blank FISCALIZ is meaningful (row not yet reviewed) -- keep it blank
    # on reload rather than letting a numeric round-trip turn it into the
    # literal string "nan", which downstream code wouldn't recognize as blank.
    if c.COL_FISCALIZ in consolidated.columns:
        consolidated[c.COL_FISCALIZ] = consolidated[c.COL_FISCALIZ].replace("nan", "")
    meta = json.loads(META_PATH.read_text(encoding="utf-8"))
    return {"consolidated": consolidated, **meta}


def clear() -> None:
    for p in (CONSOLIDATED_PATH, META_PATH):
        if p.exists():
            p.unlink()
