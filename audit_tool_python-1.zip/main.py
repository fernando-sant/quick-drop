#!/usr/bin/env python3
"""
CLI entry point -- the Python replacement for pressing "Atualizar tudo" in
the original workbook.

Usage:
    python main.py --notas 6793267 6793268 300001031925
    python main.py --notas-file notas.txt
    python main.py --notas-file notas.txt --skip-sap   # files already exported
"""
from __future__ import annotations
import argparse
import logging
from pathlib import Path

from audit_tool import config as c
from audit_tool.pipeline import run, save_outputs


def parse_args():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--notas", nargs="+", help="Notification numbers to process")
    src.add_argument("--notas-file", type=Path, help="Text file, one notification number per line")
    p.add_argument("--skip-sap", action="store_true",
                    help="Skip SAP extraction; assume export files are already in "
                         f"{c.DADOS_DIR}")
    p.add_argument("--reviewer", default=None, help="Name to attach to the error list")
    p.add_argument("--output-dir", type=Path, default=c.OUTPUT_DIR)
    p.add_argument("-v", "--verbose", action="store_true")
    return p.parse_args()


def main():
    args = parse_args()
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s  %(levelname)-7s  %(message)s",
    )

    notas = args.notas or [
        line.strip() for line in args.notas_file.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

    results = run(notas, skip_sap=args.skip_sap, reviewer=args.reviewer)
    paths = save_outputs(results, output_dir=args.output_dir)

    print("\nSaved:")
    for name, path in paths.items():
        print(f"  {name:12s} -> {path}")


if __name__ == "__main__":
    main()
