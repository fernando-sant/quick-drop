# Analise_Relatorio_Resumido — Python port

Python replacement for the VBA macros in
`Análise_Relatório_Resumido_V1_3_-_BACKUP.xlsb`. It reproduces the same
pipeline (log into SAP → export "Rel. Resumido" attachments → consolidate →
apply ~30 audit rules to catch mis-budgeted work-order items → build an
error list for review) with none of the file open/close, `Application.Wait`,
or full-column `AutoFill` steps the macro needed to work around Excel's
row-by-row formula model.

**Quick start:** `pip install -r requirements.txt && streamlit run app.py`

## Why bother

- **Speed.** The macro recalculates every rule as a real Excel formula
  copied down thousands of rows with `AutoFill`, then converts to values.
  The Python version is one `groupby().transform()` per rule — the full
  ~12k-row sheet in the workbook runs in well under a second instead of
  minutes.
- **Testability.** Every rule is a plain function you can unit-test, feed a
  handful of fabricated rows, and be sure of — vs. reading a wall of nested
  `SUMPRODUCT`/`IF` inside `Range("AS8").Formula2R1C1`.
- **No live Excel/SAP dependency to just check the logic.** You can run
  `rules.apply_all_rules()` against a CSV on any machine; only the SAP
  extraction step needs Windows + SAP GUI.
- **Correctness is checked, not assumed.** `validate.py` runs every rule
  against the flags the *original macro itself* had already computed and
  left in your workbook, cell by cell. Current result: **100% match on all
  379 real (non-blank) rows / 12,128 cells** in the uploaded file.

## Layout

```
audit_tool/
  config.py          paths, column names, constants
  lookups.py          loads BD_UnC / Exceção xx-FP reference tables (shipped as CSV)
  consolidate.py       merges per-Nota SAP exports (was C_Consolidar_Resumido.bas)
  rules.py             all ~30 audit rules, vectorized (was D_Formulas.bas)
  error_list.py         wide flags -> one row per issue (was E_lista_de_erros.bas)
  review_store.py        persists reviewer decisions (Status/Comentário) per issue, SQLite
  fiscaliz_store.py       persists manually-entered FISCALIZ values per row, SQLite
  run_state.py             persists the last consolidated run so the dashboard survives restarts
  excel_export.py          shared styled .xlsx writer (header, filter, colors) for downloads/CLI
  sap_extractor.py       SAP GUI scripting automation, Windows-only, with S4P->ERP fallback
                          and resume-after-crash support
                          (was X_Logar_ERP.bas, B_Salvar_Resumido.bas, Z_Encerrar_SAP.bas)
  pipeline.py             orchestrates all of the above (was A_Geral.bas)
  data/
    bd_unc.csv            exported from the workbook's BD_UnC sheet
    excecao_xxfp.csv        exported from the workbook's 'Exceção xx-FP' sheet
    explicacao_regras.csv    exported from the workbook's 'Explicação Regras' sheet
  assets/
    logo.png                drop your logo here to brand the dashboard (optional)
app.py                    Streamlit review dashboard -- the main way to use this tool
main.py                    CLI entry point (for scripted/scheduled runs without a UI)
validate.py               compares rules.py output against the workbook's own flags
```

## Dashboard (recommended)

```bash
pip install -r requirements.txt
streamlit run app.py
```

This opens a browser tab (defaults to `http://localhost:8501`) with:

- **Sidebar** — paste notification numbers (one per line, or comma/space
  separated) or upload a `.txt`/`.csv`/`.xlsx` with a column of them. No
  practical limit on how many at once; a live progress bar shows which
  notification is being fetched, from which SAP system, as it happens —
  useful when running hundreds at a time since SAP GUI automation is not
  instant.
- **📊 Visão Geral** — headline numbers, a bar chart of which rules are
  firing most, the notas with the most problems, and a banner telling you
  how many rows still need `FISCALIZ` filled in.
- **📋 Linhas Analisadas** — every consolidated row, filterable by Nota,
  free-text search, Alerta, or "only rows where rule X fired." `FISCALIZ`
  is editable right in the table (it never comes from SAP — a reviewer
  always had to type it in, previously by hand in Excel); edit it and hit
  **Salvar Fiscalização e recalcular regras** to re-score instantly without
  re-running SAP extraction. Values persist across sessions.
- **⚠️ Erros / Revisão** — one row per flagged issue, filterable by rule/
  status/nota, with an editable **Status** (Pendente/Aprovado/Corrigido/Não
  Aplicável) and **Comentário** per issue — a real review workflow instead
  of a spreadsheet nobody remembers to update. Saved to SQLite, so it's
  still there next time you open the app, even after re-running the
  pipeline.
- **📖 Regras** — every rule's plain-language explanation (from the
  workbook's own "Explicação Regras" sheet), searchable, with a live count
  of how many times each one fired in the current run.
- **🔍 Notas Não Encontradas** — which notifications needed the historical
  (ERP) system, and which weren't found anywhere, with the reason.

Everything (filtered views, the error list, the missing-notas list) has an
Excel download button.

## Since the last version: auto-save/resume, styled exports, logo

- **Auto-save & restore.** Every successful run (and every FISCALIZ
  recalculation) saves the consolidated data to
  `<AUDIT_OUTPUT_DIR>/last_run/`. Opening the dashboard fresh — new
  process, new browser session, whatever — restores it automatically
  (rules re-apply in well under a second; nothing is re-fetched from SAP)
  and pre-fills the notas box with what was running. A **🗑️ Descartar
  execução salva** button in the sidebar clears it if you want a clean
  slate.
- **Resume an interrupted SAP batch.** `export_all_with_fallback()` now
  checks `config.DADOS_DIR` first and skips any notification that already
  has a file there — so if SAP GUI automation dies 300 notifications into a
  batch of 500, restarting only fetches the 200 that are actually missing.
  Toggle this off in the sidebar ("Retomar execução anterior") to force a
  full refetch.
- **Styled Excel exports.** Every `.xlsx` this tool produces (dashboard
  download buttons and CLI output alike) now gets a bold frozen header,
  autofilter, sane column widths, and `Alerta`/`Status` columns colored
  with Excel's own familiar green/red convention — via
  `audit_tool/excel_export.py`. Styling every cell doesn't scale past a
  few thousand rows in openpyxl, so the per-cell body font is skipped above
  5,000 rows; header/filter/widths/color-coding still apply regardless of
  size.
- **Logo.** `audit_tool/assets/logo.png` (CPFL Energia) is wired in already
  — header, sidebar, and browser tab icon all pick it up automatically. To
  swap it later, just replace that file; no code changes needed.

## Command line (for scripts / scheduled jobs)

```bash
pip install -r requirements.txt

# If the "<Nota> - Relatório Resumido.xls" files are already in C:\DADOS:
python main.py --notas 6793267 6793268 300001031925 --skip-sap

# Full pipeline, driving SAP GUI to export first (Windows + SAP GUI required):
python main.py --notas-file notas.txt
```

Outputs land in `C:\DADOS\saida\` (override with `AUDIT_OUTPUT_DIR` or
`--output-dir`): `consolidated.xlsx`, `flagged.xlsx` (every row + every rule
column, same shape as the "Consolidação Resumido" sheet), and `errors.xlsx`
(one row per flagged issue, same shape as the HOME sheet's error list).

Paths and the SAP connection name are read from environment variables
(`AUDIT_DADOS_DIR`, `AUDIT_OUTPUT_DIR`, `AUDIT_SAP_CONNECTION`,
`AUDIT_SAP_LOGON_PATH`) with the workbook's original defaults, so nothing
needs to be hardcoded if you'd rather not edit `config.py`.

## Two SAP systems (current + historical)
Some documents haven't migrated to the current production system and only
exist in the historical one. `sap_extractor.export_all_with_fallback()`
handles this automatically:

1. Connects to `config.SAP_CONNECTIONS[0]` (**3-S/4 on Hana - Produção**,
   SID `S4P`) and tries every notification there.
2. Anything that fails for *any* reason (not found, download error) is
   retried against `config.SAP_CONNECTIONS[1]` (**3-SAP ERP - Produção
   Histórico**, SID `ERP`).
3. Returns which system each notification's document actually came from,
   so `pipeline.py` can log which ones needed the historical fallback.

To add a third system later, just append another `{"name": ..., "sid": ...}`
to `SAP_CONNECTIONS` in `config.py` — the fallback loop tries them in order
automatically.

`connect_or_open_sap()` also now reuses an already-open SAP session for the
*specific* system requested (matched by connection description) rather than
assuming "whatever's open is the right one," since two systems can be open
side by side.

## FISCALIZ: the manual step that's now an actual workflow

`FISCALIZ` never comes from SAP — the original workbook expected someone to
type it directly into the consolidated sheet after every export, with no
way to save that work except leaving the workbook open. This port persists
it (SQLite, keyed by a stable per-row id) and puts it in an editable table
in the dashboard's **📋 Linhas Analisadas** tab, so:

- filling it in is a normal data-grid edit, not hunting for the right Excel
  row across a workbook with 12k+ lines;
- values survive closing the app, re-running the pipeline, or re-exporting
  from SAP;
- hitting **Salvar Fiscalização e recalcular regras** re-scores every rule
  against the new values in under a second, instead of re-running macros.

Until a row's `FISCALIZ` is filled in, `Divergência Fisc. X Executado`
correctly flags it as needing review (this matches the original formula's
behavior: a blank cell compares as different from `EXEC`) — the "Visão
Geral" tab surfaces a count of how many rows are still pending this so nothing
gets lost in a large batch.

## What changed vs. the VBA, on purpose
  case-insensitive (matching how Excel's `=` compares text) — the source
  data has both `"OK"` and `"Ok"`, and a literal Python `==` would have
  silently disagreed with the original on those rows. Validated against the
  workbook's own output.
- **`EST TF LV MO/FIX Indevida`**: the original formula grouped by
  `R[-6]C[...]` — six rows above the current one — instead of the current
  row's own Nota/Ponto, unlike every other "Indevida" rule in the same
  module. That reads like a broken `AutoFill` reference rather than
  intended logic, so this port groups by the current row's own
  (Nota, Ponto), consistent with `Amarração Indevida`, `MO Cabo Indevida`,
  and `Conex LV Indevida` right next to it.

## Needs your review before relying on it

- **`E-UnC Complem.`**: the original formula's cell reference resolves to
  the `P/V` column (e.g. `"P1"`, `"V3"`), not `TIPO MAO DE OBRA`, even
  though the rule's own description talks about the "UnC Complementar"
  classification. Ported literally to match the formula, but this smells
  like it's checking the wrong column in the original workbook too — check
  against a row where `TIPO MAO DE OBRA` is actually `"UC Compl"` and
  confirm the flag behaves the way you expect operationally.
- **`Equipamento Reclassificado`**: no formula for this column existed in
  the extracted VBA project — it may be filled by something outside
  `Aplicar_formulas` (a lookup against the `Transformadores` sheet,
  perhaps). It's a stub returning blank here; tell me how it should behave
  and I'll fill it in.
- **SAP GUI element IDs** in `sap_extractor.py` are copied straight from
  the working macro, but I can't test them here (no SAP session available).
  If your SAP GUI version/variant differs even slightly, re-record the
  click path with SAP's own script recorder and diff it against
  `export_relatorio_resumido()`.
