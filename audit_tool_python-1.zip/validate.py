"""
Validates rules.py against the flags the ORIGINAL VBA macro already computed
and left in the workbook ('consolidacao_full_with_flags.csv', exported
straight from the uploaded .xlsb before any Python code touched it).

For every rule column: how many rows match, and a few examples of any
mismatch, so disagreements can be inspected instead of trusted blindly.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))

import pandas as pd
from audit_tool import config as c
from audit_tool.rules import apply_all_rules

# Export your workbook's "Consolidação Resumido" sheet (with its existing
# formula results still in the rule columns) to CSV and point this at it to
# re-run this check against your own data.
GROUND_TRUTH = "consolidacao_full_with_flags.csv"

raw = pd.read_csv(GROUND_TRUTH, dtype=str, keep_default_na=False)
raw = raw.loc[:, ~raw.columns.str.match(r"^Unnamed")]
raw = raw[raw[c.COL_NOTA] != ""].reset_index(drop=True)

truth = raw.copy()
for col in (c.COL_UNC, c.COL_PLANEJ, c.COL_EXEC, c.COL_FISCALIZ):
    truth[col] = pd.to_numeric(truth[col], errors="coerce")

# FISCALIZ is not part of the SAP export (A8:L) -- it's filled in separately
# (by a reviewer, after consolidation). Included here for validation only.
cols_for_rules = c.SOURCE_COLUMNS + [c.COL_FISCALIZ]
result = apply_all_rules(raw[cols_for_rules].copy())

print(f"{'RULE':38s} {'match':>7s} {'mismatch':>9s}  total")
print("-" * 70)
overall_match, overall_total = 0, 0
for col in c.RULE_COLUMNS + ["Alerta"]:
    truth_col = truth[col].fillna("").astype(str).str.strip()
    result_col = result[col].fillna("").astype(str).str.strip()
    match = (truth_col == result_col).sum()
    total = len(truth_col)
    overall_match += match
    overall_total += total
    flag = "" if match == total else "  <-- CHECK"
    print(f"{col:38s} {match:7d} {total-match:9d}  {total}{flag}")
    if match != total:
        mism = truth_col[truth_col != result_col].index[:3]
        for idx in mism:
            print(f"      row {idx}: truth={truth_col[idx]!r} vs python={result_col[idx]!r} "
                  f"(UNC={truth.loc[idx, c.COL_UNC]}, OP={truth.loc[idx, c.COL_OPERATION]})")

print("-" * 70)
print(f"OVERALL: {overall_match}/{overall_total} cells match "
      f"({100*overall_match/overall_total:.2f}%)")
