# mvcs — um sistema de controle de versão minimalista

`mvcs` é um sistema de controle de versão construído do zero, em Python puro,
para funcionar 100% localmente — sem precisar de internet, GitHub ou qualquer
servidor externo. Ele imita de perto o funcionamento interno do Git, então
tudo que você aprender aqui se aplica diretamente ao Git de verdade.

Tudo fica guardado numa pasta `.mvcs/` dentro do seu projeto, do mesmo jeito
que o Git usa a pasta `.git/`.

## Conceitos por trás da ferramenta

- **Armazenamento endereçado por conteúdo** — cada arquivo (blob), cada
  "foto" de diretório (tree) e cada commit é salvo com um nome que é o hash
  SHA-1 do seu próprio conteúdo. Isso significa que conteúdo idêntico nunca é
  salvo duas vezes, e qualquer corrupção muda o hash — ou seja, você ganha
  verificação de integridade de graça.
- **Área de staging (index)** — um mapa simples de "caminho do arquivo → hash
  do blob". É o que o comando `commit` realmente registra, separado do que
  está no disco naquele momento.
- **Trees** — snapshots recursivos de diretórios, construídos a partir do
  index. Cada commit aponta para uma tree raiz, que aponta para subtrees, que
  apontam para blobs.
- **Commits** — uma tree + um ponteiro para o commit anterior (parent) +
  metadados. É esse ponteiro para o parent que transforma uma pilha de
  fotografias em um histórico navegável.
- **Branches** — um branch nada mais é do que um arquivo de texto guardando
  um hash de commit. `HEAD` aponta para qual branch está "ativo" no momento.
  Criar um branch é barato porque é só copiar um hash para um arquivo novo.

## Instalação

Você só precisa do Python 3 (nenhuma biblioteca externa é usada).

1. Salve o `vcs.py` em um lugar fixo no seu computador, por exemplo:
   ```bash
   mkdir -p ~/bin
   cp vcs.py ~/bin/vcs.py
   ```
2. Crie um atalho (`alias`) para não precisar digitar o caminho inteiro toda
   vez. Veja a seção **Configuração no VS Code** abaixo para o passo a passo
   completo, incluindo Windows.

## Comandos disponíveis

| Comando | O que faz |
|---|---|
| `vcs init` | Cria o repositório `.mvcs/` na pasta atual |
| `vcs add <arquivo...>` | Coloca arquivo(s) na área de staging |
| `vcs status` | Mostra o que está staged, modificado ou não rastreado |
| `vcs commit -m "mensagem"` | Grava um novo commit com o que está staged |
| `vcs log` | Mostra o histórico de commits do branch atual |
| `vcs diff <arquivo>` | Mostra as diferenças entre o staged e o que está no disco |
| `vcs branch` | Lista os branches (o atual é marcado com `*`) |
| `vcs branch <nome>` | Cria um novo branch a partir do commit atual |
| `vcs checkout <branch\|hash>` | Troca de branch, ou volta para um commit específico (todo o projeto) |
| `vcs restore <arquivo\|pasta> [--source <branch\|hash>]` | Restaura **só** aquele arquivo/pasta, sem mexer no resto nem trocar de branch |
| `vcs cat-file <hash>` | Mostra o conteúdo bruto de um objeto salvo (bom para explorar como tudo funciona por dentro) |

## Fluxo de trabalho no dia a dia

```bash
vcs status                      # o que mudou desde o último commit?
vcs add arquivo1.py pasta/      # coloca em staging o que você quer registrar
vcs commit -m "descrição clara do que mudou"
vcs log                         # revisa o histórico
```

### Voltar para uma versão anterior (tudo)

```bash
vcs log                         # ache o hash do commit desejado (os 10 primeiros caracteres já bastam)
vcs checkout a1b2c3d4e5         # restaura TODOS os arquivos daquele commit
```

Isso te deixa em **HEAD destacado** (você está olhando uma foto antiga, mas
não está "em cima" de nenhum branch). Se quiser continuar trabalhando a
partir dali, crie um branch ali mesmo:

```bash
vcs branch experimento
vcs checkout experimento
```

### Restaurar só um arquivo (sem afetar o resto do projeto)

```bash
vcs restore main.py --source a1b2c3d4e5      # só main.py volta para aquela versão
vcs restore src/ --source main                # restaura a pasta inteira a partir do branch "main"
vcs restore main.py                            # sem --source, restaura a partir do HEAD atual
```

Diferente do `checkout`, o `restore` nunca move o `HEAD` nem troca de
branch — ele só mexe nos caminhos que você indicou, e deixa o resultado
**staged** (pronto para revisão antes de virar commit).

### Rede de segurança

Se você tiver mudanças não commitadas, `checkout` **recusa** rodar (para não
apagar seu trabalho sem querer):

```
error: you have staged or unstaged changes that checkout would overwrite.
commit them first, or re-run with --force to discard them.
```

Use `--force` só quando tiver certeza de que quer descartar essas mudanças.

## Configuração no VS Code

### 1. Criar um atalho de terminal

Em vez de copiar o `vcs.py` em cada projeto, deixe-o num lugar fixo e crie
um atalho de terminal.

**macOS / Linux** — adicione ao final do seu `~/.bashrc` ou `~/.zshrc`:
```bash
alias vcs='python3 ~/bin/vcs.py'
```
Depois rode `source ~/.bashrc` (ou `~/.zshrc`) ou apenas abra um terminal
novo no VS Code para o atalho valer.

**Windows (PowerShell)** — abra seu perfil do PowerShell com
`notepad $PROFILE` e adicione:
```powershell
function vcs { python3 "$HOME\bin\vcs.py" @args }
```
Salve, feche e abra um novo terminal PowerShell dentro do VS Code.

A partir daí, dentro de qualquer projeto, basta digitar `vcs init`,
`vcs add .`, `vcs commit -m "..."`, etc.

### 2. Usar o terminal integrado do VS Code

Abra o terminal integrado com `` Ctrl+` `` (ou `Cmd+`` no Mac), navegue até
a pasta do seu projeto e rode os comandos por ali mesmo enquanto edita o
código nas abas ao lado. Não existe integração visual com o painel
"Source Control" do VS Code (ele só reconhece repositórios Git de verdade) —
então esse fluxo é sempre via terminal, o que na verdade ajuda a entender de
verdade o que cada comando está fazendo.

### 3. Esconder a pasta `.mvcs` do explorador de arquivos

Para não poluir a árvore de arquivos nem a busca do VS Code, crie (ou edite)
o arquivo `.vscode/settings.json` na raiz do seu projeto:

```json
{
  "files.exclude": { "**/.mvcs": true },
  "search.exclude": { "**/.mvcs": true }
}
```

### 4. (Opcional) Criar tarefas rápidas

Se quiser rodar `status` ou `log` com um atalho de teclado em vez de digitar
no terminal, crie `.vscode/tasks.json`:

```json
{
  "version": "2.0.0",
  "tasks": [
    {
      "label": "vcs: status",
      "type": "shell",
      "command": "vcs status",
      "problemMatcher": []
    },
    {
      "label": "vcs: log",
      "type": "shell",
      "command": "vcs log",
      "problemMatcher": []
    }
  ]
}
```
Depois é só usar `Ctrl+Shift+P` → **"Tasks: Run Task"** → escolher a tarefa.

### Um fluxo sugerido

1. Edita o código.
2. `vcs status` para ver o que mudou.
3. `vcs add <arquivos>`.
4. `vcs commit -m "mensagem clara"`.
5. Antes de tentar algo arriscado, `vcs branch experimento` primeiro, para
   deixar o branch principal intacto.

## Limitações (de propósito)

Esta ferramenta foi feita para ensinar os conceitos, não para substituir o
Git em projetos sérios. O que falta, se algum dia você precisar:

- **Merge de branches** — hoje não existe um jeito de juntar dois branches
  de volta; seria necessário implementar um merge de três vias (comparar
  ambos os branches contra o ancestral comum).
- **Arquivos a ignorar** (tipo `.gitignore`) — hoje tudo que está na pasta
  é considerado.
- **Sincronização entre máquinas** — não existe `push`/`pull`; o repositório
  vive só na máquina onde foi criado.

Vale lembrar: o Git de verdade não precisa de internet nem de conta no
GitHub para nada do fluxo local (`init`, `add`, `commit`, `branch`,
`checkout`) — GitHub só entra em cena quando você sincroniza com um
repositório remoto via `push`/`pull`. Então este projeto também serve como
um preview bem próximo do que você ganharia instalando o Git de verdade.
