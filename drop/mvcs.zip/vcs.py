#!/usr/bin/env python3
"""
mvcs — a minimal version control system, built from scratch.

This is a teaching implementation of the core ideas behind Git:
  - content-addressable storage (objects are named by the hash of their content)
  - three object types: blob (file contents), tree (directory listing), commit (snapshot + metadata)
  - a staging area ("index") that separates "what's on disk" from "what's about to be committed"
  - a linear commit history via parent pointers (a real chain, just without merge support yet)

Everything lives under a `.mvcs/` directory, mirroring how Git uses `.git/`.

Usage:
  python3 vcs.py init
  python3 vcs.py add <file> [<file> ...]
  python3 vcs.py status
  python3 vcs.py commit -m "message"
  python3 vcs.py log
  python3 vcs.py diff <file>
  python3 vcs.py checkout <commit-hash>
  python3 vcs.py cat-file <hash>
"""

import argparse
import difflib
import hashlib
import json
import os
import sys
import time
import zlib
from typing import Optional

VCS_DIR = ".mvcs"
OBJECTS_DIR = os.path.join(VCS_DIR, "objects")
REFS_DIR = os.path.join(VCS_DIR, "refs", "heads")
HEAD_FILE = os.path.join(VCS_DIR, "HEAD")
INDEX_FILE = os.path.join(VCS_DIR, "index")
DEFAULT_BRANCH = "main"


# ---------------------------------------------------------------------------
# Low-level object store
#
# Every object (blob, tree, commit) is stored the same way Git stores it:
#   header = b"<type> <byte-length-of-content>\0"
#   raw    = header + content
#   hash   = sha1(raw).hexdigest()
#   stored at .mvcs/objects/<hash[:2]>/<hash[2:]>, zlib-compressed
#
# Because the filename IS the hash of the content, two identical files
# anywhere in your history are stored exactly once. This one idea —
# "name it by what it contains, not where it lives" — is what everything
# else in a VCS is built on top of.
# ---------------------------------------------------------------------------

def hash_object(data: bytes, obj_type: str, write: bool = True) -> str:
    header = f"{obj_type} {len(data)}\0".encode()
    full = header + data
    sha = hashlib.sha1(full).hexdigest()
    if write:
        path = os.path.join(OBJECTS_DIR, sha[:2], sha[2:])
        if not os.path.exists(path):
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "wb") as f:
                f.write(zlib.compress(full))
    return sha


def read_object(sha: str):
    path = os.path.join(OBJECTS_DIR, sha[:2], sha[2:])
    if not os.path.exists(path):
        raise ValueError(f"object {sha} not found")
    with open(path, "rb") as f:
        full = zlib.decompress(f.read())
    header, _, content = full.partition(b"\0")
    obj_type, _ = header.decode().split(" ")
    return obj_type, content


# ---------------------------------------------------------------------------
# Index (staging area) — a simple path -> blob-hash map, saved as JSON.
# Real Git's index is a binary file with extra metadata (mtime, mode, etc);
# we keep just enough to demonstrate why a staging area exists at all:
# it's the thing `commit` actually snapshots, decoupled from whatever is
# currently sitting on disk.
# ---------------------------------------------------------------------------

def read_index() -> dict:
    if not os.path.exists(INDEX_FILE):
        return {}
    with open(INDEX_FILE) as f:
        return json.load(f)


def write_index(index: dict):
    with open(INDEX_FILE, "w") as f:
        json.dump(index, f, indent=2, sort_keys=True)


# ---------------------------------------------------------------------------
# Trees — recursive directory snapshots built from the flat index.
# Each line in a tree object is:  "<type> <hash> <name>"
# where type is "blob" (a file) or "tree" (a subdirectory).
# ---------------------------------------------------------------------------

def build_tree(paths: dict) -> str:
    """paths: {relative/posix/path: blob_hash}. Returns hash of the root tree."""
    groups = {}
    direct = {}
    for path, blob_hash in paths.items():
        if "/" in path:
            head, rest = path.split("/", 1)
            groups.setdefault(head, {})[rest] = blob_hash
        else:
            direct[path] = blob_hash

    lines = []
    for name, blob_hash in direct.items():
        lines.append(f"blob {blob_hash} {name}")
    for name, sub_paths in groups.items():
        sub_hash = build_tree(sub_paths)
        lines.append(f"tree {sub_hash} {name}")

    content = "\n".join(sorted(lines)).encode()
    return hash_object(content, "tree")


def read_tree(tree_hash: str, prefix: str = "") -> dict:
    """Flatten a tree object back into {relative/posix/path: blob_hash}."""
    obj_type, content = read_object(tree_hash)
    assert obj_type == "tree"
    result = {}
    if not content:
        return result
    for line in content.decode().split("\n"):
        entry_type, entry_hash, name = line.split(" ", 2)
        full_path = f"{prefix}{name}"
        if entry_type == "blob":
            result[full_path] = entry_hash
        else:
            result.update(read_tree(entry_hash, prefix=f"{full_path}/"))
    return result


# ---------------------------------------------------------------------------
# Refs — HEAD normally points AT a branch name, and the branch file holds
# a commit hash. This indirection (HEAD -> refs/heads/main -> commit) is
# what makes branching cheap: a branch is just a movable pointer, and
# committing on a branch just rewrites one small text file.
#
# HEAD can also point directly at a commit hash instead of a branch —
# that's "detached HEAD" (checking out a specific old commit rather than
# the tip of a branch). Same distinction real Git makes.
# ---------------------------------------------------------------------------

def is_detached() -> bool:
    with open(HEAD_FILE) as f:
        content = f.read().strip()
    return not content.startswith("refs/heads/")


def current_branch() -> Optional[str]:
    with open(HEAD_FILE) as f:
        ref = f.read().strip()
    if not ref.startswith("refs/heads/"):
        return None
    return ref.split("refs/heads/")[-1]


def branch_path(branch: str) -> str:
    return os.path.join(REFS_DIR, branch)


def list_branches() -> list:
    if not os.path.isdir(REFS_DIR):
        return []
    return sorted(os.listdir(REFS_DIR))


def get_head_commit() -> Optional[str]:
    with open(HEAD_FILE) as f:
        content = f.read().strip()
    if content.startswith("refs/heads/"):
        branch = content.split("refs/heads/")[-1]
        path = branch_path(branch)
        if os.path.exists(path):
            with open(path) as bf:
                value = bf.read().strip()
                return value or None
        return None
    # detached: HEAD holds a raw commit hash
    return content or None


def set_head_commit(sha: str):
    """Advance whatever HEAD currently points at (a branch, or itself if detached)."""
    branch = current_branch()
    if branch is not None:
        with open(branch_path(branch), "w") as f:
            f.write(sha)
    else:
        with open(HEAD_FILE, "w") as f:
            f.write(sha)


def set_head_to_branch(branch: str):
    with open(HEAD_FILE, "w") as f:
        f.write(f"refs/heads/{branch}")


def set_head_detached(sha: str):
    with open(HEAD_FILE, "w") as f:
        f.write(sha)


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def cmd_init(args):
    if os.path.exists(VCS_DIR):
        print(f"{VCS_DIR} already exists")
        return
    os.makedirs(OBJECTS_DIR)
    os.makedirs(REFS_DIR)
    with open(HEAD_FILE, "w") as f:
        f.write(f"refs/heads/{DEFAULT_BRANCH}")
    write_index({})
    print(f"Initialized empty mvcs repository in {os.path.abspath(VCS_DIR)}")


def cmd_add(args):
    index = read_index()
    for path in args.paths:
        if not os.path.isfile(path):
            print(f"skip (not a file): {path}")
            continue
        with open(path, "rb") as f:
            data = f.read()
        blob_hash = hash_object(data, "blob")
        index[path.replace(os.sep, "/")] = blob_hash
        print(f"staged {path} -> {blob_hash[:10]}")
    write_index(index)


def _walk_working_dir():
    on_disk = []
    for root, dirs, files in os.walk("."):
        dirs[:] = [d for d in dirs if d != VCS_DIR and not d.startswith(".")]
        for name in files:
            path = os.path.relpath(os.path.join(root, name), ".").replace(os.sep, "/")
            on_disk.append(path)
    return on_disk


def cmd_status(args):
    index = read_index()
    head = get_head_commit()
    committed = {}
    if head:
        _, content = read_object(head)
        commit = parse_commit(content)
        committed = read_tree(commit["tree"])

    on_disk = _walk_working_dir()

    staged_new = [p for p in index if p not in committed]
    staged_modified = [p for p in index if p in committed and index[p] != committed[p]]
    not_staged = []
    for path in on_disk:
        with open(path, "rb") as f:
            current_hash = hash_object(f.read(), "blob", write=False)
        if path in index and index[path] != current_hash:
            not_staged.append(path)
    untracked = [p for p in on_disk if p not in index and p not in committed]

    def section(title, items):
        if items:
            print(f"\n{title}:")
            for i in sorted(set(items)):
                print(f"  {i}")

    branch = current_branch()
    if branch:
        print(f"On branch {branch}")
    else:
        print(f"HEAD detached at {(head or '')[:10]}")
    section("Staged (new)", [p for p in staged_new if p not in staged_modified])
    section("Staged (modified)", staged_modified)
    section("Modified, not staged", not_staged)
    section("Untracked", untracked)
    if not any([staged_new, staged_modified, not_staged, untracked]):
        print("\nnothing to commit, working directory clean")


def cmd_commit(args):
    index = read_index()
    if not index:
        print("nothing staged — use `add` first")
        return
    tree_hash = build_tree(index)
    parent = get_head_commit()

    lines = [f"tree {tree_hash}"]
    if parent:
        lines.append(f"parent {parent}")
    lines.append(f"author {args.author} {int(time.time())}")
    lines.append("")
    lines.append(args.message)
    content = "\n".join(lines).encode()

    commit_hash = hash_object(content, "commit")
    set_head_commit(commit_hash)
    print(f"[{current_branch()} {commit_hash[:10]}] {args.message}")


def parse_commit(content: bytes) -> dict:
    text = content.decode()
    header, _, message = text.partition("\n\n")
    result = {"message": message, "parent": None}
    for line in header.split("\n"):
        key, _, value = line.partition(" ")
        if key == "tree":
            result["tree"] = value
        elif key == "parent":
            result["parent"] = value
        elif key == "author":
            result["author"] = value
    return result


def cmd_log(args):
    sha = get_head_commit()
    if not sha:
        print("no commits yet")
        return
    while sha:
        _, content = read_object(sha)
        commit = parse_commit(content)
        print(f"commit {sha}")
        if "author" in commit:
            name, ts = commit["author"].rsplit(" ", 1)
            when = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(int(ts)))
            print(f"Author: {name}")
            print(f"Date:   {when}")
        print(f"\n    {commit['message'].strip()}\n")
        sha = commit["parent"]


def cmd_diff(args):
    index = read_index()
    path = args.path
    old_content = b""
    if path in index:
        _, old_content = read_object(index[path])
    if not os.path.isfile(path):
        print(f"{path}: not found in working directory")
        return
    with open(path, "rb") as f:
        new_content = f.read()
    diff = difflib.unified_diff(
        old_content.decode(errors="replace").splitlines(keepends=True),
        new_content.decode(errors="replace").splitlines(keepends=True),
        fromfile=f"staged/{path}",
        tofile=f"working/{path}",
    )
    sys.stdout.writelines(diff)


def cmd_branch(args):
    if not args.name:
        current = current_branch()
        for b in list_branches():
            marker = "*" if b == current else " "
            print(f"{marker} {b}")
        return
    head = get_head_commit()
    if head is None:
        print("no commits yet — make a commit before branching")
        return
    path = branch_path(args.name)
    if os.path.exists(path):
        print(f"branch '{args.name}' already exists")
        return
    with open(path, "w") as f:
        f.write(head)
    print(f"created branch '{args.name}' at {head[:10]}")


def _uncommitted_changes() -> bool:
    """True if there's staged or unstaged work that a checkout would clobber."""
    index = read_index()
    head = get_head_commit()
    committed = {}
    if head:
        _, content = read_object(head)
        committed = read_tree(parse_commit(content)["tree"])
    if index != committed:
        return True
    for path in _walk_working_dir():
        with open(path, "rb") as f:
            current_hash = hash_object(f.read(), "blob", write=False)
        if path in index and index[path] != current_hash:
            return True
    return False


def _restore_files(files: dict):
    for path, blob_hash in files.items():
        _, data = read_object(blob_hash)
        dirname = os.path.dirname(path)
        if dirname:
            os.makedirs(dirname, exist_ok=True)
        with open(path, "wb") as f:
            f.write(data)
    write_index(files)


def resolve_object_prefix(prefix: str) -> str:
    """Find the one full object hash starting with `prefix` (like Git's abbreviated hashes)."""
    if len(prefix) == 40 and os.path.exists(os.path.join(OBJECTS_DIR, prefix[:2], prefix[2:])):
        return prefix
    if len(prefix) < 4:
        raise ValueError("hash prefix too short, use at least 4 characters")
    shard_dir = os.path.join(OBJECTS_DIR, prefix[:2])
    if not os.path.isdir(shard_dir):
        raise ValueError(f"no object matches '{prefix}'")
    candidates = [prefix[:2] + rest for rest in os.listdir(shard_dir)
                  if (prefix[:2] + rest).startswith(prefix)]
    if not candidates:
        raise ValueError(f"no object matches '{prefix}'")
    if len(candidates) > 1:
        raise ValueError(f"ambiguous prefix '{prefix}', matches: {', '.join(candidates)}")
    return candidates[0]


def resolve_commit_ref(ref: str) -> str:
    """ref can be a branch name or a commit hash/prefix. Returns a full commit hash."""
    if ref in list_branches():
        with open(branch_path(ref)) as f:
            sha = f.read().strip()
        if not sha:
            raise ValueError(f"branch '{ref}' has no commits yet")
        return sha
    return resolve_object_prefix(ref)


def cmd_restore(args):
    source_ref = args.source or get_head_commit()
    if source_ref is None:
        print("no commits yet")
        return
    try:
        commit_hash = resolve_commit_ref(source_ref)
        obj_type, content = read_object(commit_hash)
    except ValueError as e:
        print(f"error: {e}")
        return
    if obj_type != "commit":
        print(f"'{source_ref}' is not a commit or branch")
        return

    files = read_tree(parse_commit(content)["tree"])
    index = read_index()
    any_restored = False

    for path in args.paths:
        norm = path.replace(os.sep, "/").rstrip("/")
        if norm in files:
            matches = {norm: files[norm]}
        else:
            # allow restoring a whole directory, like `git restore src/`
            dir_prefix = norm + "/"
            matches = {p: h for p, h in files.items() if p.startswith(dir_prefix)}

        if not matches:
            print(f"'{path}' not found in {commit_hash[:10]}")
            continue

        for p, blob_hash in matches.items():
            _, data = read_object(blob_hash)
            dirname = os.path.dirname(p)
            if dirname:
                os.makedirs(dirname, exist_ok=True)
            with open(p, "wb") as f:
                f.write(data)
            index[p] = blob_hash
            any_restored = True

        print(f"restored {len(matches)} file(s) under '{path}' from {commit_hash[:10]}")

    if any_restored:
        write_index(index)
        print("(these paths are now staged at the restored version — `commit` to keep it, "
              "or `checkout` your branch again with --force to undo)")


def cmd_checkout(args):
    target = args.target

    if not args.force and _uncommitted_changes():
        print("error: you have staged or unstaged changes that checkout would overwrite.")
        print("commit them first, or re-run with --force to discard them.")
        return

    branches = list_branches()
    if target in branches:
        sha = None
        with open(branch_path(target)) as f:
            sha = f.read().strip() or None
        if sha is None:
            print(f"branch '{target}' has no commits yet")
            return
        _, content = read_object(sha)
        files = read_tree(parse_commit(content)["tree"])
        _restore_files(files)
        set_head_to_branch(target)
        print(f"Switched to branch '{target}' ({sha[:10]}) — {len(files)} file(s) restored")
        return

    # otherwise treat target as a commit hash
    try:
        obj_type, content = read_object(target)
    except ValueError:
        print(f"'{target}' is not a known branch or commit")
        return
    if obj_type != "commit":
        print(f"{target} is not a commit")
        return
    files = read_tree(parse_commit(content)["tree"])
    _restore_files(files)
    set_head_detached(target)
    print(f"checked out {target[:10]} — {len(files)} file(s) restored")
    print("note: you are in 'detached HEAD'. Commits made here aren't on any branch.")
    print(f"      run `vcs.py branch <name>` now if you want to keep working from this point.")


def cmd_cat_file(args):
    obj_type, content = read_object(args.hash)
    print(f"type: {obj_type}")
    print(f"size: {len(content)} bytes\n")
    try:
        print(content.decode())
    except UnicodeDecodeError:
        print("(binary content)")


# ---------------------------------------------------------------------------
# CLI wiring
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(prog="vcs.py", description="A minimal version control system.")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("init").set_defaults(func=cmd_init)

    p = sub.add_parser("add")
    p.add_argument("paths", nargs="+")
    p.set_defaults(func=cmd_add)

    sub.add_parser("status").set_defaults(func=cmd_status)

    p = sub.add_parser("commit")
    p.add_argument("-m", "--message", required=True)
    p.add_argument("--author", default="you <you@local>")
    p.set_defaults(func=cmd_commit)

    sub.add_parser("log").set_defaults(func=cmd_log)

    p = sub.add_parser("diff")
    p.add_argument("path")
    p.set_defaults(func=cmd_diff)

    p = sub.add_parser("branch")
    p.add_argument("name", nargs="?", help="create a branch at the current commit; omit to list branches")
    p.set_defaults(func=cmd_branch)

    p = sub.add_parser("restore")
    p.add_argument("paths", nargs="+", help="file(s) or directory to restore")
    p.add_argument("--source", help="branch name or commit hash/prefix to restore from (default: HEAD)")
    p.set_defaults(func=cmd_restore)

    p = sub.add_parser("checkout")
    p.add_argument("target", help="a branch name or a commit hash")
    p.add_argument("--force", action="store_true", help="discard uncommitted changes")
    p.set_defaults(func=cmd_checkout)

    p = sub.add_parser("cat-file")
    p.add_argument("hash")
    p.set_defaults(func=cmd_cat_file)

    args = parser.parse_args()

    if args.command != "init" and not os.path.exists(VCS_DIR):
        print("not a mvcs repository (run `vcs.py init` first)")
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()
