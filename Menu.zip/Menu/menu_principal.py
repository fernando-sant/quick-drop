import sys
import pkgutil
import importlib
import inspect

from PyQt6.QtWidgets import (
    QApplication,
    QWidget,
    QVBoxLayout,
    QLabel,
    QPushButton,
    QMessageBox,
)

import utils
from utils.base import UtilitarioBase


def descobrir_utilitarios():
    """Varre o pacote utils/ e retorna todas as classes que herdam de UtilitarioBase.

    Basta criar um novo arquivo em utils/ com uma classe que herde de
    UtilitarioBase para que ela apareça aqui automaticamente — não é
    preciso editar este arquivo.
    """
    encontrados = []
    for _, nome_modulo, _ in pkgutil.iter_modules(utils.__path__, prefix="utils."):
        try:
            modulo = importlib.import_module(nome_modulo)
        except Exception as e:
            print(f"⚠️ Falha ao importar {nome_modulo}: {e}")
            continue
        for _, obj in inspect.getmembers(modulo, inspect.isclass):
            if issubclass(obj, UtilitarioBase) and obj is not UtilitarioBase:
                encontrados.append(obj)
    # remove duplicatas (a mesma classe pode aparecer via mais de um módulo)
    return list(dict.fromkeys(encontrados))


class MenuPrincipal(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🧰 Utilitários")
        self.setFixedWidth(280)

        # Mapa classe -> instância aberta, para não duplicar janelas
        # e para não perder a referência (garbage collector).
        self.janelas_abertas = {}

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Escolha um utilitário:"))

        utilitarios = descobrir_utilitarios()
        if not utilitarios:
            layout.addWidget(QLabel("Nenhum utilitário encontrado em utils/."))

        for classe in utilitarios:
            botao = QPushButton(classe.NOME)
            botao.clicked.connect(lambda _, classe=classe: self.abrir(classe))
            layout.addWidget(botao)

    def abrir(self, classe):
        # Se essa ferramenta já está aberta, só traz a janela pra frente
        # em vez de criar uma segunda instância.
        janela_existente = self.janelas_abertas.get(classe)
        if janela_existente is not None and janela_existente.isVisible():
            janela_existente.raise_()
            janela_existente.activateWindow()
            return

        try:
            janela = classe()
        except Exception as e:
            QMessageBox.critical(
                self,
                "Erro ao abrir utilitário",
                f"Não foi possível abrir '{classe.NOME}':\n\n{e}",
            )
            return

        janela.show()
        self.janelas_abertas[classe] = janela


if __name__ == "__main__":
    app = QApplication(sys.argv)
    menu = MenuPrincipal()
    menu.show()
    sys.exit(app.exec())
