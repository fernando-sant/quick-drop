import math
import re

from PyQt6.QtCore import Qt, QRegularExpression, QTimer
from PyQt6.QtGui import QRegularExpressionValidator, QGuiApplication
from PyQt6.QtWidgets import (
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QFormLayout,
    QGroupBox,
    QCheckBox,
    QComboBox,
    QLineEdit,
    QTextEdit,
    QPushButton,
    QLabel,
    QTabWidget,
    QWidget,
    QTableWidget,
    QTableWidgetItem,
)

from utils.base import UtilitarioBase


class PotenciaInjetavel(UtilitarioBase):
    """Calculadora de Máxima Potência Injetável (Inciso IV).

    Base: Manual de Instruções - art. 73, §1º da REN nº 1.000/2021 (ANEEL),
    itens 8.12, 8.15 e 8.17.

    O consumo médio pode ser informado de três formas: valor já calculado,
    os 12 valores mensais digitados (o programa calcula a média simples),
    ou colando os 12 valores de uma célula/coluna do Excel ou da área de
    transferência.
    """

    NOME = "Pg (Inciso IV)"

    FC = 0.16  # fixo para geração solar
    FA_MAP = {
        "residencial": ("Residencial", 0.46),
        "industrial": ("Industrial", 0.69),
        "comercio": ("Comércio, serviços e outras atividades", 0.63),
        "rural": ("Rural", 0.53),
        "servico_publico": ("Serviço Público", 0.57),
    }

    NUM_VALIDATOR = QRegularExpression(r'^-?\d*[.,]?\d*$')

    def __init__(self):
        super().__init__()
        self.setWindowTitle(self.NOME)
        self.setMinimumSize(500, 560)
        self.setWindowFlags(Qt.WindowType.Window)

        layout = QVBoxLayout(self)
        layout.addWidget(self._criar_secao_checklist())
        layout.addWidget(self._criar_secao_dados())

        self.btn_calcular = QPushButton("Calcular →")
        self.btn_calcular.setEnabled(False)
        self.btn_calcular.clicked.connect(self._calcular)
        layout.addWidget(self.btn_calcular)

        self.aviso = QLabel("Marque as condições, escolha a classe e informe o consumo.")
        self.aviso.setWordWrap(True)
        layout.addWidget(self.aviso)

        self.resultado_box = self._criar_secao_resultado()
        self.resultado_box.setVisible(False)
        layout.addWidget(self.resultado_box)

        nota = QLabel(
            "Base: Manual de Instruções – art. 73, §1º da REN nº 1.000/2021 (ANEEL). "
            "Itens 8.12, 8.15 e 8.17. Cálculo indicativo; a distribuidora pode adotar "
            "procedimentos internos complementares."
        )
        nota.setWordWrap(True)
        nota.setStyleSheet("color: #6D6E71; font-size: 11px;")
        layout.addWidget(nota)

    # ---- seção 1: checklist ----

    def _criar_secao_checklist(self):
        grupo = QGroupBox("1) Antes de começar")
        v = QVBoxLayout(grupo)
        textos = [
            "Tenho 12 ciclos completos de faturamento.",
            "Não houve troca de titularidade nos últimos 12 meses.",
            "Não houve alteração cadastral relevante (classe/tarifa/tipo "
            "de fornecimento) nos últimos 12 meses.",
            "A UC não é de Iluminação Pública nem de Consumo Próprio.",
        ]
        self.checks = []
        for texto in textos:
            caixa = QCheckBox(texto)
            caixa.stateChanged.connect(self._validar)
            v.addWidget(caixa)
            self.checks.append(caixa)
        return grupo

    # ---- seção 2: classe + consumo (3 modos) ----

    def _criar_secao_dados(self):
        grupo = QGroupBox("2) Dados para o cálculo")
        v = QVBoxLayout(grupo)

        form_classe = QFormLayout()
        self.combo_classe = QComboBox()
        self.combo_classe.addItem("Selecione…", None)
        for chave, (nome, fa) in self.FA_MAP.items():
            self.combo_classe.addItem(f"{nome} (FA {fa:.0%})", chave)
        self.combo_classe.currentIndexChanged.connect(self._validar)
        form_classe.addRow("Classe da UC:", self.combo_classe)
        v.addLayout(form_classe)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._criar_aba_media(), "Média direta")
        self.tabs.addTab(self._criar_aba_meses(), "Digitar 12 valores")
        self.tabs.addTab(self._criar_aba_colar(), "Colar do Excel")
        self.tabs.currentChanged.connect(self._validar)
        v.addWidget(self.tabs)

        dica = QLabel(
            "FC fixo em 16% (solar). Se houver benefício do art. 186, informe "
            "apenas o consumo no horário sem redução."
        )
        dica.setWordWrap(True)
        dica.setStyleSheet("color: #6D6E71; font-size: 11px;")
        v.addWidget(dica)

        return grupo

    def _criar_aba_media(self):
        aba = QWidget()
        form = QFormLayout(aba)
        self.campo_media = QLineEdit()
        self.campo_media.setPlaceholderText("Ex: 1000")
        self.campo_media.setValidator(QRegularExpressionValidator(self.NUM_VALIDATOR))
        self.campo_media.textChanged.connect(self._validar)
        form.addRow("Consumo médio 12 meses (kWh):", self.campo_media)
        return aba

    def _criar_aba_meses(self):
        aba = QWidget()
        v = QVBoxLayout(aba)
        v.addWidget(QLabel("Digite o consumo (kWh) de cada um dos 12 meses:"))

        grade = QGridLayout()
        self.campos_meses = []
        for i in range(12):
            campo = QLineEdit()
            campo.setPlaceholderText(f"Mês {i + 1}")
            campo.setValidator(QRegularExpressionValidator(self.NUM_VALIDATOR))
            campo.textChanged.connect(self._validar)
            grade.addWidget(QLabel(f"Mês {i + 1}"), i // 3, (i % 3) * 2)
            grade.addWidget(campo, i // 3, (i % 3) * 2 + 1)
            self.campos_meses.append(campo)
        v.addLayout(grade)

        self.label_media_meses = QLabel("Preencha os 12 meses.")
        self.label_media_meses.setStyleSheet("color: #0058A0; font-weight: bold;")
        v.addWidget(self.label_media_meses)
        return aba

    def _criar_aba_colar(self):
        aba = QWidget()
        v = QVBoxLayout(aba)
        v.addWidget(QLabel(
            "Cole os 12 valores como copiados do Excel (uma linha ou uma "
            "coluna) ou de qualquer outra fonte:"
        ))

        self.campo_colar = QTextEdit()
        self.campo_colar.setPlaceholderText(
            "Cole aqui (Ctrl+V)...\nEx:\n350\n412,5\n398\n..."
        )
        self.campo_colar.setFixedHeight(110)
        self.campo_colar.textChanged.connect(self._validar)
        v.addWidget(self.campo_colar)

        linha_botao = QHBoxLayout()
        btn_colar = QPushButton("📋 Colar da área de transferência")
        btn_colar.clicked.connect(self._colar_da_area_transferencia)
        linha_botao.addWidget(btn_colar)
        linha_botao.addStretch()
        v.addLayout(linha_botao)

        self.label_media_colar = QLabel("Nenhum valor colado ainda.")
        self.label_media_colar.setStyleSheet("color: #0058A0; font-weight: bold;")
        self.label_media_colar.setWordWrap(True)
        v.addWidget(self.label_media_colar)
        return aba

    def _colar_da_area_transferencia(self):
        texto = QGuiApplication.clipboard().text()
        if texto:
            self.campo_colar.setPlainText(texto)

    # ---- seção 3: resultado ----

    def _criar_secao_resultado(self):
        grupo = QGroupBox("3) Resultado")
        v = QVBoxLayout(grupo)

        self.label_kw = QLabel("")
        self.label_kw.setAlignment(Qt.AlignmentFlag.AlignCenter)
        fonte = self.label_kw.font()
        fonte.setPointSize(22)
        fonte.setBold(True)
        self.label_kw.setFont(fonte)

        self.label_tag = QLabel("")
        self.label_tag.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.label_formula = QLabel("")
        self.label_formula.setWordWrap(True)
        self.label_formula.setStyleSheet("color: #444;")

        self.btn_tabela = QPushButton("Ver comparação por classe ▾")
        self.btn_tabela.setCheckable(True)
        self.btn_tabela.toggled.connect(self._alternar_tabela)

        self.tabela = QTableWidget(0, 4)
        self.tabela.setHorizontalHeaderLabels(["Classe", "FA", "Bruto", "Arredondado"])
        self.tabela.horizontalHeader().setStretchLastSection(True)
        self.tabela.verticalHeader().setVisible(False)
        self.tabela.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.tabela.setVisible(False)

        v.addWidget(self.label_kw)
        v.addWidget(self.label_tag)
        v.addWidget(self.label_formula)
        v.addWidget(self.btn_tabela)
        v.addWidget(self.tabela)

        return grupo

    # ---- leitura do consumo conforme a aba ativa ----

    @staticmethod
    def _normalizar_numero(token):
        token = token.strip()
        if not token:
            return None
        if "," in token and "." in token:
            token = token.replace(".", "").replace(",", ".")
        elif "," in token:
            token = token.replace(",", ".")
        try:
            return float(token)
        except ValueError:
            return None

    def _extrair_numeros(self, texto):
        tokens = re.split(r"\s+", texto.strip())
        valores = []
        for token in tokens:
            if not token:
                continue
            limpo = re.sub(r"[^0-9.,-]", "", token)
            if not limpo:
                continue
            valor = self._normalizar_numero(limpo)
            if valor is not None:
                valores.append(valor)
        return valores

    def _status_consumo(self):
        """Retorna (consumo_ou_None, mensagem_de_bloqueio_ou_None) conforme a aba ativa."""
        indice = self.tabs.currentIndex()

        if indice == 0:
            valor = self._normalizar_numero(self.campo_media.text())
            if valor is None or valor <= 0:
                return None, "Informe a média mensal de consumo (kWh)."
            return valor, None

        if indice == 1:
            preenchidos, invalidos, valores = 0, 0, []
            for campo in self.campos_meses:
                texto = campo.text().strip()
                if not texto:
                    continue
                preenchidos += 1
                valor = self._normalizar_numero(texto)
                if valor is None:
                    invalidos += 1
                else:
                    valores.append(valor)
            if preenchidos < 12:
                self.label_media_meses.setText(f"Preenchidos {preenchidos}/12 meses.")
                return None, f"Preencha os 12 meses (faltam {12 - preenchidos})."
            if invalidos > 0 or len(valores) != 12:
                self.label_media_meses.setText("Há valores inválidos entre os 12 meses.")
                return None, "Confira os valores digitados nos 12 meses."
            media = sum(valores) / 12
            self.label_media_meses.setText(f"Média calculada: {media:.2f} kWh")
            return media, None

        # indice == 2: colar do Excel / área de transferência
        valores = self._extrair_numeros(self.campo_colar.toPlainText())
        if len(valores) != 12:
            if valores:
                self.label_media_colar.setText(
                    f"{len(valores)} valor(es) encontrado(s) — eram esperados 12."
                )
            else:
                self.label_media_colar.setText("Nenhum valor colado ainda.")
            return None, f"Cole exatamente os 12 valores mensais (encontrados: {len(valores)})."
        media = sum(valores) / 12
        self.label_media_colar.setText(f"12 valores encontrados. Média calculada: {media:.2f} kWh")
        return media, None

    # ---- validação ----

    def _validar(self):
        todos_marcados = all(c.isChecked() for c in self.checks)
        classe_ok = self.combo_classe.currentData() is not None
        consumo, motivo = self._status_consumo()

        pronto = todos_marcados and classe_ok and consumo is not None
        self.btn_calcular.setEnabled(pronto)

        if not todos_marcados:
            self.aviso.setText(
                "⚠️ Cálculo não aplicável para este caso: confira as condições da seção 1."
            )
        elif not classe_ok:
            self.aviso.setText("Selecione a classe da UC.")
        elif motivo:
            self.aviso.setText(motivo)
        else:
            self.aviso.setText(f"Tudo certo! Consumo considerado: {consumo:.2f} kWh. Clique em Calcular.")

    # ---- cálculo ----

    def _calcular(self):
        consumo, _ = self._status_consumo()
        if consumo is None:
            return

        chave = self.combo_classe.currentData()
        nome_classe, fa = self.FA_MAP[chave]

        bruto, arredondado = self._calcular_pg(consumo, fa)

        self.label_kw.setText(f"{arredondado} kW")
        self.label_tag.setText(f"{nome_classe} • FA {fa:.0%}")
        self.label_formula.setText(
            f"Pg = {consumo:.2f} / (0,16 × 24h × 30d) × {fa:.2f} = {bruto:.3f} kW\n"
            f"Arredondado por elevação: {arredondado} kW"
        )

        self._preencher_tabela(consumo)
        self.resultado_box.setVisible(True)
        self.tabela.setVisible(True)
        self.btn_tabela.setChecked(True)
        self.btn_tabela.setText("Ocultar comparação ▴")

        # Ajusta a janela ao novo conteúdo (resultado + tabela) depois que
        # o Qt processar as mudanças de visibilidade/layout.
        QTimer.singleShot(0, self.adjustSize)

    def _calcular_pg(self, consumo, fa):
        denom = self.FC * 24 * 30
        bruto = consumo / denom * fa
        arredondado = math.ceil(bruto)
        return bruto, arredondado

    def _preencher_tabela(self, consumo):
        self.tabela.setRowCount(0)
        for _, (nome, fa) in self.FA_MAP.items():
            bruto, arredondado = self._calcular_pg(consumo, fa)
            linha = self.tabela.rowCount()
            self.tabela.insertRow(linha)
            self.tabela.setItem(linha, 0, QTableWidgetItem(nome))
            self.tabela.setItem(linha, 1, QTableWidgetItem(f"{fa:.0%}"))
            self.tabela.setItem(linha, 2, QTableWidgetItem(f"{bruto:.2f} kW"))
            self.tabela.setItem(linha, 3, QTableWidgetItem(f"{arredondado} kW"))

        # Dimensiona a tabela para caber exatamente as linhas, sem
        # scrollbar interna, para que adjustSize() calcule certo.
        self.tabela.resizeRowsToContents()
        altura = self.tabela.horizontalHeader().height() + 4
        for linha in range(self.tabela.rowCount()):
            altura += self.tabela.rowHeight(linha)
        self.tabela.setFixedHeight(altura)

    def _alternar_tabela(self, ligado):
        self.tabela.setVisible(ligado)
        self.btn_tabela.setText("Ocultar comparação ▴" if ligado else "Ver comparação por classe ▾")
        QTimer.singleShot(0, self.adjustSize)


if __name__ == "__main__":
    import sys
    from PyQt6.QtWidgets import QApplication

    app = QApplication(sys.argv)
    janela = PotenciaInjetavel()
    janela.show()
    sys.exit(app.exec())
