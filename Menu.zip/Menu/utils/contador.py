from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QLabel, QVBoxLayout, QTextEdit

from utils.base import UtilitarioBase


class ContadorCaracteres(UtilitarioBase):
    """Exemplo de segundo utilitário: conta caracteres de um texto colado."""

    NOME = "🔢 Contador de Caracteres"

    def __init__(self):
        super().__init__()
        self.setWindowTitle("🔢 Contador de Caracteres")
        self.setFixedSize(320, 160)
        self.setWindowFlags(
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Window
        )
        layout = QVBoxLayout(self)
        self.info = QLabel("Cole ou digite um texto:")
        self.campo = QTextEdit()
        self.resultado = QLabel("Caracteres: 0")
        layout.addWidget(self.info)
        layout.addWidget(self.campo)
        layout.addWidget(self.resultado)
        self.campo.textChanged.connect(self.processar)

    def processar(self):
        texto = self.campo.toPlainText()
        self.resultado.setText(f"Caracteres: {len(texto)}")
