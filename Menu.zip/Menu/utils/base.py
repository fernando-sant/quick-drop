from PyQt6.QtWidgets import QWidget


class UtilitarioBase(QWidget):
    """Classe base que todo utilitário do menu deve herdar.

    Basta definir o atributo de classe NOME (texto do botão no menu) e
    a ferramenta passa a aparecer automaticamente no menu principal —
    sem precisar registrar nada manualmente em outro arquivo.
    """
    NOME: str = "Utilitário sem nome"
