import re

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QGuiApplication
from PyQt6.QtWidgets import QLabel, QVBoxLayout, QLineEdit

from utils.base import UtilitarioBase


class ConversorCoordenadas(UtilitarioBase):
    """Converte coordenadas entre o formato DMS do Google Maps
    (ex: 23°20'17.7"S 46°28'15.2"W) e decimal (ex: -23.338237 -46.470898).

    Observação: esta é uma conversão de FORMATO/NOTAÇÃO, não uma
    transformação de datum. Ela assume que a coordenada já está no
    sistema de referência correto (SIRGAS2000) nos dois lados — apenas
    muda como o mesmo ponto é escrito.
    """

    NOME = "🌍 Conversor de Coordenadas"

    # Aceita variações comuns: º ou °, ' ou ′, " ou ″, vírgula ou ponto
    # decimal nos segundos, e O (Oeste) além de W.
    PADRAO_DMS = re.compile(
        r'(\d{1,3})\s*[°º]\s*(\d{1,2})\s*[\'′]\s*([\d.,]+)\s*[\"″]?\s*([NnSsEeWwOo])'
    )
    PADRAO_DECIMAL = re.compile(r'-?\d{1,3}[.,]\d+')

    def __init__(self):
        super().__init__()
        self.setWindowTitle(self.NOME)
        self.setFixedSize(430, 130)
        self.setWindowFlags(
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Window
        )

        layout = QVBoxLayout(self)
        self.info = QLabel("Cole a coordenada (DMS ou decimal) — SIRGAS2000:")
        self.campo = QLineEdit()
        self.campo.setPlaceholderText(
            '''23°20'17.7"S 46°28'15.2"W  ou  -23.338237 -46.470898'''
        )
        self.resultado = QLineEdit()
        self.resultado.setReadOnly(True)
        self.resultado.setPlaceholderText("O resultado aparece aqui...")

        layout.addWidget(self.info)
        layout.addWidget(self.campo)
        layout.addWidget(self.resultado)

        self.campo.textChanged.connect(self.processar)
        self.campo.setFocus()

    def processar(self, texto):
        texto = texto.strip()
        if not texto:
            self.resultado.clear()
            return

        if "°" in texto or "º" in texto:
            resultado = self._dms_para_decimal(texto)
        else:
            resultado = self._decimal_para_dms(texto)

        if resultado:
            QGuiApplication.clipboard().setText(resultado)
            self.resultado.setText(resultado)
            self.resultado.selectAll()
            self.info.setText("✅ Copiado para a área de transferência:")
        else:
            self.resultado.clear()
            self.info.setText("⚠️ Não consegui interpretar — confira o formato.")

    # ---- DMS -> decimal ----

    def _dms_para_decimal(self, texto):
        matches = self.PADRAO_DMS.findall(texto)
        if len(matches) < 2:
            return None
        lat = self._converter_um_dms(*matches[0])
        lon = self._converter_um_dms(*matches[1])
        return f"{lat:.6f} {lon:.6f}"

    @staticmethod
    def _converter_um_dms(graus, minutos, segundos, hemisferio):
        segundos = float(segundos.replace(",", "."))
        decimal = float(graus) + float(minutos) / 60 + segundos / 3600
        if hemisferio.upper() in ("S", "W", "O"):
            decimal = -decimal
        return decimal

    # ---- decimal -> DMS ----

    def _decimal_para_dms(self, texto):
        numeros = self.PADRAO_DECIMAL.findall(texto)
        if len(numeros) < 2:
            return None
        lat = float(numeros[0].replace(",", "."))
        lon = float(numeros[1].replace(",", "."))
        return f"{self._converter_um_decimal(lat, 'lat')} {self._converter_um_decimal(lon, 'lon')}"

    @staticmethod
    def _converter_um_decimal(valor, eixo):
        hemisferio = ("S" if valor < 0 else "N") if eixo == "lat" else ("W" if valor < 0 else "E")
        valor = abs(valor)
        graus = int(valor)
        resto_min = (valor - graus) * 60
        minutos = int(resto_min)
        segundos = round((resto_min - minutos) * 60, 1)
        # ajusta arredondamentos que "estouram" 60
        if segundos >= 60:
            segundos -= 60
            minutos += 1
        if minutos >= 60:
            minutos -= 60
            graus += 1
        return f'{graus}°{minutos}\'{segundos:.1f}"{hemisferio}'


if __name__ == "__main__":
    import sys
    from PyQt6.QtWidgets import QApplication

    app = QApplication(sys.argv)
    janela = ConversorCoordenadas()
    janela.show()
    sys.exit(app.exec())
