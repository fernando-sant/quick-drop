import re
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QGuiApplication
from PyQt6.QtWidgets import QLabel, QVBoxLayout, QLineEdit

from utils.base import UtilitarioBase


class Limpador(UtilitarioBase):
    """Remove tudo que não for dígito de um texto colado e copia o resultado."""

    NOME = "📋 Limpador de Dígitos"

    def __init__(self):
        super().__init__()
        self.setWindowTitle("📋 Limpador de Dígitos")
        self.setFixedSize(320, 90)
        self.setWindowFlags(
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Window
        )
        layout = QVBoxLayout(self)
        self.info = QLabel("Cole aqui (Ctrl+V):")
        self.campo = QLineEdit()
        self.campo.setPlaceholderText("Cole o número formatado...")
        layout.addWidget(self.info)
        layout.addWidget(self.campo)
        self.campo.textChanged.connect(self.processar)
        self.campo.setFocus()

    def processar(self, texto):
        if not texto:
            return
        numero = re.sub(r"\D", "", texto)
        if numero:
            QGuiApplication.clipboard().setText(numero)
            self.info.setText(f"✅ Copiado: {numero}")
        self.campo.blockSignals(True)
        self.campo.clear()
        self.campo.blockSignals(False)
        self.campo.setFocus()


# Permite continuar rodando este arquivo sozinho, se necessário
if __name__ == "__main__":
    import sys
    from PyQt6.QtWidgets import QApplication

    app = QApplication(sys.argv)
    janela = Limpador()
    janela.show()
    sys.exit(app.exec())
